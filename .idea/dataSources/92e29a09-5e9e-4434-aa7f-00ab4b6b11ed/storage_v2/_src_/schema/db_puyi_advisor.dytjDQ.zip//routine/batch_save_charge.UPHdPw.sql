create
    definer = hs@`%` procedure batch_save_charge()
begin
			declare startId int default 1;
			declare endId int default 300;
			declare maxId int;
			set maxId = (select max(id) from db_puyi_advisor.fad_bs_advise_charge_request_his_tmp20220524);
			while(startId <= maxId) do
			insert into db_puyi_advisor.fad_bs_advise_charge_request_his_tmp20220523
			select * from db_puyi_advisor.fad_bs_advise_charge_request_his_tmp20220524 t where t.id between startId and endId;
			set startId = startId + 300;
			set endId = endId + 300;
			# 休眠0.2秒
			select sleep(0.2);
		end while;
	end;


create
    definer = hs@`%` procedure BATCH_SAVE_ASSET()
BEGIN
    DECLARE n int DEFAULT 0;
        WHILE(n<2000000) DO
            INSERT INTO `db_puyi_advisor`.`fad_sb_custom_intransit_asset_temp`( `CLIENT_ID`, `TRADE_ACCOUNT`, `COMB_CODE`, `TRADE_DATE`, `INTRANSIT_ASSET_TYPE`, `INTRANSIT_ASSET_AMOUNT`, `SALE_NET_NO`, `ADVISOR_NO`, `FILE_DATE`) VALUES (LPAD(FLOOR(RAND() * 999999.99), 6, '0'), CONCAT('ZHLC',LPAD(FLOOR(RAND() * 999999.99), 6, '0')), 'A006ZH201497', '20220225', '2', 1046.33, '0001', 'A006', '20220302');
        set n = n + 1;
        END WHILE;
   END;


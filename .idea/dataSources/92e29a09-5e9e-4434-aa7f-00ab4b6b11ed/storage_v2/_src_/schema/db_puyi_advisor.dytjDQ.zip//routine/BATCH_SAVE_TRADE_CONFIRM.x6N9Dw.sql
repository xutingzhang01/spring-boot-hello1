create
    definer = hs@`%` procedure BATCH_SAVE_TRADE_CONFIRM()
BEGIN
    DECLARE n int DEFAULT 0;
        WHILE(n<2000000) DO
            INSERT INTO `db_puyi_advisor`.`fad_sb_custom_stock_info_temp`(`CLIENT_ID`, `TRADE_ACCOUNT`, `COMB_CODE`, `COMB_COMPONENT_SHARE_DETAIL`, `SALE_NET_NO`, `ADVISOR_NO`, `FILE_DATE`) VALUES (LPAD(FLOOR(RAND() * 999999.99), 6, '0'), CONCAT('ZHLC',LPAD(FLOOR(RAND() * 999999.99), 6, '0')), 'A006ZH201522', '{[000300,2000.00,2000.00,0.00],[002310,6965.16,0.00,0.00],[002210,10945.26,0.00,0.00]}', '0001', 'A006', '20220302');
        set n = n + 1;
        END WHILE;
   END;


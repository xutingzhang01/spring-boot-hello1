create
    definer = hs@`%` procedure redeem_allot_proc(IN adjustdate char(8), IN adviserdetailproduct varchar(255),
                                                 IN combCode varchar(255), OUT result varchar(500))
begin 
DECLARE redeemallotproduct varchar(255); -- 所有赎回转购产品对应关系
DECLARE redeemproduct varchar(255); -- 赎回产品代码
DECLARE allotproduct varchar(255); -- 转购产品diamante
DECLARE zhuangou integer DEFAULT 0; -- 是否执行转购，0不转购，1转购
DECLARE zhuangouproductcode varchar(255) DEFAULT ''; -- 单笔转购产品
DECLARE allzhuangouproductcode varchar(255) DEFAULT ''; -- 所有转购产品
DECLARE allnum integer DEFAULT 0; -- 需要统计的转购总数
DECLARE redeemdate char(8); -- 赎回日期
DECLARE allotdate char(8); -- 转购日期
DECLARE allotrequestnum integer; -- 单天转购申请
DECLARE redeemrequestnum integer; -- 赎回申请
DECLARE redeemallotnum integer DEFAULT 0; -- 单天转购产品数
DECLARE noallotproduct varchar(500); -- 未转购的所有赎回转购产品对应关系
set redeemallotproduct=adviserdetailproduct;
set redeemproduct = SUBSTR(redeemallotproduct FROM 1 FOR 6);
set allotproduct = SUBSTR(redeemallotproduct FROM 8 FOR 6);
set redeemallotnum = 0;
set allnum = LENGTH(adviserdetailproduct) - LENGTH(REPLACE(adviserdetailproduct,',',''));
set redeemdate = adjustdate;
set allotdate = DATE_FORMAT(DATE_ADD(STR_TO_DATE(redeemdate,'%Y%m%d'),INTERVAL 1 day),'%Y%m%d');
set result ='';
set noallotproduct = adviserdetailproduct;
while LENGTH(noallotproduct)>0 do

set redeemproduct = SUBSTR(noallotproduct FROM 1 FOR 6);
set allotproduct = SUBSTR(noallotproduct FROM 8 FOR 6);
set noallotproduct = '';
while LENGTH(redeemallotproduct)>0 and LENGTH(redeemproduct)=6 and LENGTH(allotproduct)=6 do
select if(t2.allotUpDay>t1.redeemDownDay,1,0),t2.vc_product_code into zhuangou,zhuangouproductcode from 
(select a.VC_PRODUCT_CODE,a.C_PRODUCT_TYPE,b.L_FOF_CONFIRM_DAY,b.L_QDII_CONFIRM_DAY,b.L_ALLOT_CONFIRM_DAY,c.C_LIQUIDATE_FLAG,if(c.L_DAY is null,1,c.L_DAY) capDay,
DATE_ADD(STR_TO_DATE(redeemdate,'%Y%m%d'),INTERVAL (ifnull(max(c.L_DAY),1) + 1) day) redeemDownDay
from tc_tproductinfo a 
left join tc_tproductinfodetail b on a.VC_TENANT_ID=b.VC_TENANT_ID and a.VC_PRODUCT_CODE = b.VC_PRODUCT_CODE
left join tc_tcapitaldate c on a.VC_TENANT_ID = b.VC_TENANT_ID and a.VC_PRODUCT_CODE = c.VC_PRODUCT_CODE
where a.VC_PRODUCT_CODE = redeemproduct and c.C_LIQUIDATE_FLAG = '02') t1,

(select a.VC_PRODUCT_CODE,a.C_PRODUCT_TYPE,b.L_FOF_CONFIRM_DAY,b.L_QDII_CONFIRM_DAY,b.L_ALLOT_CONFIRM_DAY,c.C_LIQUIDATE_FLAG,if(c.L_DAY is null,1,c.L_DAY) capDay,
DATE_ADD(STR_TO_DATE(allotdate,'%Y%m%d'),INTERVAL (ifnull(max(c.L_DAY),1) + if((case when a.C_PRODUCT_TYPE = '6' then b.L_FOF_CONFIRM_DAY when a.C_PRODUCT_TYPE = '5' then b.L_QDII_CONFIRM_DAY else b.L_ALLOT_CONFIRM_DAY end) is null,0,(case when a.C_PRODUCT_TYPE = '6' then b.L_FOF_CONFIRM_DAY when a.C_PRODUCT_TYPE = '5' then b.L_QDII_CONFIRM_DAY else b.L_ALLOT_CONFIRM_DAY end)) + 1) day) allotUpDay
from tc_tproductinfo a 
left join tc_tproductinfodetail b on a.VC_TENANT_ID=b.VC_TENANT_ID and a.VC_PRODUCT_CODE = b.VC_PRODUCT_CODE
left join tc_tcapitaldate c on a.VC_TENANT_ID = b.VC_TENANT_ID and a.VC_PRODUCT_CODE = c.VC_PRODUCT_CODE
where a.VC_PRODUCT_CODE = allotproduct and c.C_LIQUIDATE_FLAG = '11') t2;

if zhuangou = 1 then 
set redeemallotnum = redeemallotnum + zhuangou;
set allzhuangouproductcode = CONCAT(allzhuangouproductcode,',',zhuangouproductcode);
else 
set noallotproduct = CONCAT(noallotproduct,redeemproduct,',',allotproduct,';');

end if;
set redeemallotproduct = SUBSTR(redeemallotproduct FROM 15 FOR LENGTH(redeemallotproduct)-14);
set redeemproduct = SUBSTR(redeemallotproduct FROM 1 FOR 6);
set allotproduct = SUBSTR(redeemallotproduct FROM 8 FOR 6);
end while;

select count(DISTINCT vc_trade_acco)*redeemallotnum into allotrequestnum from iia_tcomb_accoinfo where VC_COMB_CODE = combCode;

if allotrequestnum > 0 then 
set result = CONCAT(result,allotdate,'转购笔数:',allotrequestnum,'; ');
end if;
if LENGTH(allzhuangouproductcode) > 0 then 
set result = CONCAT(result,allotdate,'转购产品:',allzhuangouproductcode,'; ');
end if;
set allotdate = DATE_FORMAT(DATE_ADD(STR_TO_DATE(allotdate,'%Y%m%d'),INTERVAL 1 day),'%Y%m%d');
set redeemallotnum = 0;
set redeemallotproduct = noallotproduct;
end while;
select count(DISTINCT vc_trade_acco)*allnum into redeemrequestnum from iia_tcomb_accoinfo where VC_COMB_CODE = combCode;
set result = CONCAT(redeemdate,'赎回笔数:',redeemrequestnum,'; ',result);
end;


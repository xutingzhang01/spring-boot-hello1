create
    definer = hs@`%` procedure BATCH_SAVE_CUSTOM_INFO()
BEGIN
    DECLARE n int DEFAULT 0;
        WHILE(n<2000000) DO
            INSERT INTO `db_puyi_advisor`.`fad_sb_custom_info_base_temp`(`CLIENT_ID`, `CUST_NAME`, `CUST_TYPE`, `ID_CARD_TYPE`, `ID_CARD_NO`, `ID_CARD_VALID_DATE`, `PHONE_NUM`, `CUSTOMER_RISK_ABILITY`, `RISK_QUESTION_ANSWER`, `RISK_ASSESSMENT_DUE_DATE`, `PROFESSIONAL_INVESTOR_FLAG`, `CUSTOMER_DETAIL_INFO`, `PHOTOCOPY_FILE_ADDRESS`, `UPDATE_TIME`, `SALE_NET_NO`, `ADVISOR_NO`, `FILE_DATE`) VALUES (LPAD(FLOOR(RAND() * 999999.99), 6, '0'), CONCAT('测试',LPAD(FLOOR(RAND() * 999999.99), 6, '0')), '1', '0', LPAD(FLOOR(RAND() * 999999999999999999.99), 18, '0'), '20500101', CONCAT('86|158',LPAD(FLOOR(RAND() * 999999999.99), 9, '0')), 5, '{\"您的主要收入来源是\":\"利息、股息、转让等金融性资产收入\",\"您的家庭可支配年收入为（折合人民币）?\":\"1000万元及以上\",\"在您每年家庭可支配收入中，可用于金融投资（储蓄存款除外）的比例为?\":\"大于50%\",\"你是否有尚未清偿的数额较大的债务，如有，其性质是\":\"没有\",\"您的投资知识可描述为：\":\"丰富：对金融产品及其相关风险具有丰富的知识和理解\",\"您的投资经验可描述为：\":\"参与过权证、期货、期权等产品的交易\",\"您有多少年投资基金、股票、信托、私募证券或金融衍生产品等风险投资的经验？\":\"10年以上\",\"您计划的投资期限是多久?\":\"5年以上\",\"您打算重点投资于哪种类型的投资品种?\":\"债券、货币市场基金、债券基金等固定收益类投资品种\",\"以下哪项描述最符合您的投资态度?\":\"希望赚取高回报，愿意为此承担较大本金损失\",\"假设有两种投资：投资A获得预期10%的收益，可能承担的损失非常小;投资预期获得30%收益，但可能承受较大亏损。您会怎样支配您的投资：\":\"全部投资于收益较大且风险较大的B\",\"您认为自己能承受的最大投资损失是多少?\":\"超过30%\"}', '20221013235959', '0', '{\"sex\":\"1\",\"vocationCode\":\"04\",\"address\":\"11|1101|110102|朝阳区群众1221\",\"nationality\":\"156\",\"nonResiFlag\":\"0\",\"creditFlag\":\"0\",\"beneOwner\":\"0\",\"beneOwnerName\":\"\",\"beneOwnerCertType\":\"\",\"beneOwnerCertNo\":\"\",\"actualController\":\"0\",\"actualControllerName\":\"\",\"actualControllerCertificateType\":\"\",\"actualControllerCertificateNo\":\"\"}', NULL, '20211224000000', '8888', 'A006', '20220302'); 
        set n = n + 1;
        END WHILE;
   END;


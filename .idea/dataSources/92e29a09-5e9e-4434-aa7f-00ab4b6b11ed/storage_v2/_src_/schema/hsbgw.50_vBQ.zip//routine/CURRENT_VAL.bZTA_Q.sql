create
    definer = hs@`%` function CURRENT_VAL(seq_name varchar(50)) returns decimal(32)
BEGIN
    DECLARE value numeric(32,0);
    SET value = 0;
    SELECT current_value INTO value
    FROM sequence
    WHERE name = seq_name;
    RETURN value;
END;


create
    definer = hs@`%` procedure create_table_proc()
begin
    declare v_rowcount integer;
    select count(1)
    into v_rowcount
    from (select * from information_schema.columns where table_schema = (SELECT DATABASE())) t
    where upper(table_name) = upper('BG_TDICTIONARY');
    if v_rowcount = 0 then
        CREATE TABLE `BG_TDICTIONARY`
        (
            `L_KEYNO`        decimal(10, 0)                                          NOT NULL comment '字典编号',
            `C_KEYVALUE`     varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci  NOT NULL comment '字典值',
            `C_CAPTION`      varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL comment '字典描述',
            `C_MODIFY`       char(1) CHARACTER SET utf8 COLLATE utf8_general_ci      NULL DEFAULT NULL comment '是否可修改',
            `C_MEMO`         varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci  NULL DEFAULT NULL comment '备注',
            `VC_TRANSLATION` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL comment '翻译值',
            `C_SORT` int(10) NULL DEFAULT NULL comment '排序值',
            UNIQUE INDEX `DICT_UNIQUE` (`C_KEYVALUE`, `L_KEYNO`) USING BTREE
        ) comment = '数据字典表'
          ENGINE = InnoDB
          CHARACTER SET = utf8
          COLLATE = utf8_general_ci
          ROW_FORMAT = Dynamic;
    end if;
end;


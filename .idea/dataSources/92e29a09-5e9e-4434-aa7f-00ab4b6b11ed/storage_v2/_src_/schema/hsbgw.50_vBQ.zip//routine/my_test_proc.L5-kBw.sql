create
    definer = hs@`%` procedure my_test_proc()
begin
 declare v_rowcount integer ;
    select count(1) into v_rowcount from sequence where NAME = 'QREGISTERINFO';
    if v_rowcount = 0 then
		insert into sequence (NAME, CURRENT_VALUE, INCREMENTS)
    values ('QREGISTERINFO', '0', '1');
 end if;
end;


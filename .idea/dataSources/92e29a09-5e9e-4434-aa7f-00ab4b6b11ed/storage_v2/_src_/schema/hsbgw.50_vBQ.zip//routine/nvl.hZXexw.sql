create
    definer = hs@`%` function nvl(oriStr varchar(1000), defaultStr varchar(1000)) returns varchar(1000) deterministic
BEGIN
	RETURN IFNULL(oriStr, defaultStr);
END;


create
    definer = hs@`%` procedure schema_change()
BEGIN
IF NOT EXISTS (SELECT * FROM information_schema.statistics WHERE table_schema=DATABASE() AND table_name = 'COMP_RESULT_INFO' AND index_name = 'INDEX_COMP_SERIAL_NO') THEN
   ALTER TABLE `COMP_RESULT_INFO` ADD INDEX INDEX_COMP_SERIAL_NO ( `VC_COMP_SERIAL_NO` );
END IF;
END;


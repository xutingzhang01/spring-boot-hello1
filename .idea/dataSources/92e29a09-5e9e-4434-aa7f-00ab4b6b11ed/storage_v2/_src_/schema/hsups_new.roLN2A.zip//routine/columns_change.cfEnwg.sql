create
    definer = hs@`%` procedure columns_change()
BEGIN
IF NOT EXISTS (select column_name  from information_schema.columns where table_name = 'PAYCHANNEL_TRADING_INFO_HIS' and column_name = 'VC_REALTIME_STATUS' and TABLE_SCHEMA = database() ) THEN
ALTER TABLE PAYCHANNEL_TRADING_INFO_HIS ADD VC_REALTIME_STATUS VARCHAR(1)  COMMENT '撤单状态标识 空-未撤单 1-已发起实时撤单' ;
END IF;
END;


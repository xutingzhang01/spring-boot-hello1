create
    definer = hs@`%` procedure pro()
BEGIN  
   
declare bankno varchar(20); 
declare bankname varchar(60);
declare nameinbank varchar(200);
declare bankacco varchar(40);
declare branchbank varchar(12);
declare provincecode varchar(3);
declare cityno varchar(4);
declare mobileno varchar(40);
declare brcode varchar(12);
declare identitytype varchar(3);
declare identityno varchar(40);
declare custtype varchar(1);
declare capitalmode  varchar(2);
declare subcapitalmode varchar(4);
declare interfacetype varchar(1);
declare cdcard varchar(50);
declare custno varchar(32);
declare accoid varchar(32);
declare ups_cdcard varchar(50);
declare ups_protocal varchar(50);
declare ups_paymode varchar(4) ;

declare done int default false; 

declare count int ; 
		
    declare cur cursor for 
SELECT     
      B.C_BANK_NO,
				B.VC_BANK_NAME,
        B.VC_NAME_IN_BANK,
        B.VC_BANK_ACCO,
        B.VC_BRANCH_BANK,
        B.VC_BANK_PROVINCE_CODE,
        B.VC_BANK_CITY_NO,
        B.VC_BANK_MOBILE_NO,
				B.VC_BR_CODE,
				B.C_IDENTITY_TYPE_IN_BANK,
        B.VC_IDENTITY_NO_IN_BANK,
				D.vc_cust_no,
        D.C_CUST_TYPE,
        G.C_CAPITAL_MODE ,
        G.C_SUB_CAPITAL_MODE,
        G.C_INTERFACE_TYPE,
        G.VC_CD_CARD
        FROM hstcs.TC_TACCOBANK B, hstcs.TC_TCUSTINFO D,hstcs.tc_tcapitalacco G, hstcs.TC_TACCOINFO C
        where  B.VC_TENANT_ID=C.VC_TENANT_ID
            AND B.VC_TENANT_ID=D.VC_TENANT_ID
            AND B.VC_TENANT_ID=G.VC_TENANT_ID

            AND C.VC_CUST_NO = D.VC_CUST_NO
            AND C.VC_CUST_NO = B.VC_CUST_NO
            AND C.VC_CUST_NO = G.VC_CUST_NO
         
            AND C.VC_TRADE_ACCO = G.VC_TRADE_ACCO
            AND C.VC_BANK_CARD_NO = B.VC_BANK_CARD_NO
            AND C.VC_BANK_CARD_NO = G.VC_BANK_CARD_NO
AND D.C_CUST_STATE NOT IN('6','F','I','Y')  
and B.VC_TENANT_ID = '10000'
and G.c_capital_mode not in ('1','K')
and C_USER_TYPE is null
and not exists (
select 1 from hsups.PAYCHANNEL_OPENED_INFO ups
where ups.VC_BANK_ACCO = B.VC_BANK_ACCO 
and ups.c_capital_mode = G.c_capital_mode
and ups.c_bank_no=B.c_bank_no);


    declare continue HANDLER for not found set done = true;  
    
		 
    open cur;  
		
    fetch cur into bankno,bankname,nameinbank,bankacco,branchbank,provincecode,cityno,mobileno,brcode,identitytype,identityno,custno,custtype,capitalmode,subcapitalmode,interfacetype,cdcard;  
   
	 while(not done) do  
	 
	 

			 set ups_paymode = '0100';
			 set ups_protocal = cdcard;
			 if interfacetype=1 then
			 		 set ups_paymode = '0100';
			 else
			 		set ups_paymode = '0000';
			 end if;
       
			 select count(1) into count from hsups.PAYCHANNEL_INVESTOR_INFO where C_CUST_TYPE=custtype and C_IDENTITY_TYPE=identitytype and VC_IDENTITY_NO=identityno and VC_CUSTOM_NAME=nameinbank;
			 
			
			 if count=0 then 
				set accoid= LPAD(concat(custno,custtype,identitytype,left(identityno,6),DATE_FORMAT(now(),'%Y%m%d')),32,'0');
			 else
					select VC_PAYACNT_ACCO into accoid from hsups.PAYCHANNEL_INVESTOR_INFO where C_CUST_TYPE=custtype and C_IDENTITY_TYPE=identitytype and VC_IDENTITY_NO=identityno and VC_CUSTOM_NAME=nameinbank;
			 
			 end if;
			 
			 
INSERT INTO hsups.PAYCHANNEL_INVESTOR_INFO(`VC_PAYACNT_ACCO`, `C_CUST_TYPE`, `VC_CUSTOM_NAME`, `C_IDENTITY_TYPE`, `VC_IDENTITY_NO`, `VC_MOBILE_NO`, `C_STATUS`, `VC_CREATION_DATE`, `VC_UPDATION_DATE`, `VC_OPERATOR_NO`, `VC_AUDIT_NO`, `VC_EXPLAIN`, `VC_RESERVE_ONE`, `VC_RESERVE_TWO`, `VC_SAFE_PAY_NO`, `VC_MEMBER_NO`) select accoid, custtype, nameinbank, identitytype,identityno, mobileno, '1', DATE_FORMAT(now(),'%Y%m%d%H%i%S'), DATE_FORMAT(now(),'%Y%m%d%H%i%S'), NULL, NULL, '异常数据同步20210901', NULL, NULL, NULL, NULL from dual where not exists (select * from hsups.PAYCHANNEL_INVESTOR_INFO where  VC_PAYACNT_ACCO=accoid);
				 
INSERT INTO hsups.paychannel_account_info(`VC_PAYACNT_ACCO`, `C_BANK_NO`, `VC_BANK_NAME`, `VC_NAME_IN_BANK`, `VC_BANK_ACCO`, `C_BANK_PROVINCE_CODE`, `VC_BANK_CITY_NO`, `C_IDENTITY_TYPE_IN_BANK`, `VC_IDENTITY_NO_IN_BANK`, `VC_BANK_MOBILE_NO`, `VC_BRANCH_BANK`, `C_STATUS`, `VC_CREATION_DATE`, `VC_UPDATION_DATE`, `VC_OPERATOR_NO`, `VC_AUDIT_NO`, `VC_EXPLAIN`, `VC_RESERVE_ONE`, `VC_RESERVE_TWO`) select accoid, bankno, bankname, nameinbank,bankacco, provincecode, cityno, identitytype, identityno, mobileno, branchbank, '1', DATE_FORMAT(now(),'%Y%m%d%H%i%S'),DATE_FORMAT(now(),'%Y%m%d%H%i%S'), NULL, NULL, '异常数据同步20210901', NULL, NULL from dual where not exists (select * from hsups.paychannel_account_info where VC_PAYACNT_ACCO=accoid and VC_BANK_ACCO=bankacco and c_bank_no=bankno);
				
			 
INSERT INTO hsups.PAYCHANNEL_OPENED_INFO(`VC_PAYACNT_ACCO`, `C_CAPITAL_MODE`, `C_BANK_NO`, `VC_BANK_ACCO`, `VC_PRODUCT_NO`, `C_STATUS`, `VC_MULTIPLE_PAY_MODE`, `VC_CD_CARD`, `VC_PROTOCOL`, `VC_CREATION_DATE`, `VC_UPDATION_DATE`, `VC_OPERATOR_NO`, `VC_AUDIT_NO`, `VC_EXPLAIN`, `VC_RESERVE_ONE`, `VC_RESERVE_TWO`, `VC_PAY_AGREEMENT_NO`, `VC_BIND_CARD_ID`) select accoid, capitalmode, bankno, bankacco, '001', '1', ups_paymode, ups_cdcard, ups_protocal, DATE_FORMAT(now(),'%Y%m%d%H%i%S'), DATE_FORMAT(now(),'%Y%m%d%H%i%S'), NULL, NULL, '异常数据同步20210901', NULL, NULL, NULL, NULL  from dual where not exists ( select * from hsups.PAYCHANNEL_OPENED_INFO where VC_PAYACNT_ACCO=accoid and VC_BANK_ACCO=bankacco and c_bank_no=bankno and C_CAPITAL_MODE=capitalmode);
			 
			
       fetch cur into bankno,bankname,nameinbank,bankacco,branchbank,provincecode,cityno,mobileno,brcode,identitytype,identityno,custno,custtype,capitalmode,subcapitalmode,interfacetype,cdcard;  
   
			

    end while;  
      
    close cur;  

END;


create
    definer = hs@`%` procedure add_colum()
BEGIN
IF  NOT EXISTS (select column_name from information_schema.columns where table_name = 'UPS_CC_REQUEST_HIS' and column_name = 'VC_ACC_TYPE' and TABLE_SCHEMA = database() ) THEN
alter table UPS_CC_REQUEST_HIS add column VC_ACC_TYPE  VARCHAR(2) DEFAULT NULL  COMMENT '账号类别，10-个人支票，11-个人活期存折,12-个人银行卡,13-对公支票户,14-对公存折户,15-单位结算卡,20-内部户';
END IF;
END;


create definer = hs@`%` view pos_user_view as
select `pos`.`org_id` AS `org_id`, `pu`.`user_id` AS `user_id`
from (`hsots_new`.`tsys_position` `pos` join `hsots_new`.`tsys_pos_user` `pu`
      on (`pu`.`position_code` = `pos`.`position_code`));

-- comment on column pos_user_view.org_id not supported: 所属组织

-- comment on column pos_user_view.user_id not supported: 用户代码


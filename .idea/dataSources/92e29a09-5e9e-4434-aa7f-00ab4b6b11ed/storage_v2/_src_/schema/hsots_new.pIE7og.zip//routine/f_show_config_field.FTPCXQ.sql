create
    definer = hs@`%` procedure f_show_config_field(IN opertate_type varchar(32), IN vc_group_code varchar(200),
                                                   IN vc_config_code varchar(200), IN vc_name varchar(200),
                                                   IN vc_label varchar(200), IN vc_type varchar(32),
                                                   IN vc_field_mode varchar(32), IN vc_format varchar(200),
                                                   IN vc_sort varchar(32), IN vc_width varchar(32),
                                                   IN vc_height varchar(32), IN vc_category varchar(32),
                                                   IN vc_editable varchar(32), IN vc_orderable varchar(32),
                                                   IN vc_visible varchar(32), IN vc_fixable varchar(32),
                                                   IN vc_filter_type varchar(32), IN vc_groupable varchar(32),
                                                   IN vc_value varchar(200), IN vc_load_type varchar(32),
                                                   IN vc_default_value varchar(32), IN vc_rules varchar(200),
                                                   IN vc_messages varchar(200), IN vc_value_type varchar(32))
label:BEGIN
	DECLARE t_total INT default 0;
	DECLARE t_group_id VARCHAR(32);
	DECLARE t_config_id VARCHAR(32);
	DECLARE t_id VARCHAR(32);

SELECT count(*) INTO t_total FROM OT_TSHOWCONFIGGROUP t WHERE t.VC_SC_GROUP_CODE = vc_group_code ;

IF t_total <= 0 THEN
select concat('OT_TSHOWCONFIGGROUP不存在:',vc_group_code) ;
leave label;
END IF ;

SELECT t.VC_SC_GROUP_ID INTO t_group_id FROM OT_TSHOWCONFIGGROUP t WHERE t.VC_SC_GROUP_CODE = vc_group_code ;

SELECT count(*) INTO t_total FROM OT_TSHOWCONFIG t WHERE t.VC_SC_GROUP_ID = t_group_id AND t.VC_SC_CODE = vc_config_code ;

IF t_total <= 0 THEN
select concat('show_config不存在:',vc_config_code) ;
leave label;
END IF ;

SELECT t.VC_SC_ID INTO t_config_id FROM OT_TSHOWCONFIG t WHERE t.VC_SC_GROUP_ID = t_group_id AND t.VC_SC_CODE = vc_config_code ;

SELECT count(*) INTO t_total FROM OT_TSHOWCONFIGFIELD t WHERE t.VC_SC_ID = t_config_id AND t.VC_SC_FIELD_NAME = vc_name ;

IF t_total <= 0 AND (opertate_type = '2' OR opertate_type = '3') THEN
select concat('OT_TSHOWCONFIGFIELD不存在:',vc_name) ;
leave label;
	ELSEIF t_total > 0 AND opertate_type = '1' THEN
select concat('OT_TSHOWCONFIGFIELD已存在:',vc_name) ;
leave label;
	ELSEIF t_total > 0 THEN
SELECT t.VC_SC_FIELD_ID INTO t_id FROM OT_TSHOWCONFIGFIELD t WHERE t.VC_SC_ID = t_config_id AND t.VC_SC_FIELD_NAME = vc_name ;
END IF ;


    IF vc_width = '' THEN SET vc_width = null; END IF ;
    IF vc_height = '' THEN SET vc_height = '30'; END IF ;

	IF opertate_type = '1' THEN

		INSERT INTO OT_TSHOWCONFIGFIELD VALUES
			(null,t_config_id,vc_name,vc_label,vc_type,
			vc_field_mode,vc_format,vc_sort,vc_width,vc_height,vc_category,
			vc_editable,vc_orderable,vc_visible,vc_fixable,vc_filter_type,
			vc_groupable,vc_value,vc_load_type,vc_default_value,vc_rules,
			vc_messages,vc_value_type) ;
	ELSEIF opertate_type = '2' THEN
DELETE FROM OT_TSHOWCONFIGFIELD WHERE VC_SC_FIELD_ID = t_id ;
ELSEIF opertate_type = '3' THEN
UPDATE OT_TSHOWCONFIGFIELD
SET VC_SC_FIELD_LABEL = vc_label,VC_SC_FIELD_TYPE = vc_type,
    VC_SC_FIELD_MODE = vc_field_mode,VC_SC_FIELD_FORMAT = vc_format,
    EN_SC_FIELD_SORT = vc_sort,EN_SC_FIELD_WIDTH = vc_width,
    EN_SC_FIELD_HEIGHT = vc_height,VC_SC_FIELD_CATEGORY = vc_category,
    C_SC_FIELD_EDITABLE = vc_editable,C_SC_FIELD_ORDERABLE = vc_orderable,
    C_SC_FIELD_VISIBLE = vc_visible,C_SC_FIELD_FIXABLE = vc_fixable,
    C_SC_FIELD_FILTER_TYPE = vc_filter_type,C_SC_FIELD_GROUPABLE = vc_groupable,
    VC_SC_FIELD_VALUE_FROM = vc_value,C_SC_FIELD_LOAD_TYPE = vc_load_type,
    VC_SC_FIELD_DEFAULT_VALUE = vc_default_value,VC_SC_FIELD_RULES = vc_rules,
    C_SC_FIELD_MESSAGE = vc_messages,C_SC_FIELD_VALUE_TYPE = vc_value_type
WHERE VC_SC_FIELD_ID = t_id ;
END IF ;
COMMIT ;
end;


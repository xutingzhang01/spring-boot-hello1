create definer = hs@`%` view user_role_view as
select `ru`.`role_code`  AS `role_code`,
       `r`.`role_name`   AS `role_name`,
       `ru`.`right_flag` AS `right_flag`,
       `ru`.`user_code`  AS `user_id`,
       `r`.`role_order`  AS `role_order`,
       `r`.`tenant_id`   AS `tenant_id`,
       `r`.`kind_code`   AS `kind_code`
from `hsots_new`.`tsys_role_user` `ru`
         join `hsots_new`.`tsys_role` `r`
where `r`.`role_code` = `ru`.`role_code`
  and `ru`.`right_flag` = '1'
  and (`r`.`approval_status` is null or `r`.`approval_status` <> '1')
  and `r`.`role_status` = '1'
union
select `r`.`role_code`  AS `role_code`,
       `r`.`role_name`  AS `role_name`,
       '1'              AS `right_flag`,
       `r`.`creator`    AS `user_id`,
       `r`.`role_order` AS `role_order`,
       `r`.`tenant_id`  AS `tenant_id`,
       `r`.`kind_code`  AS `kind_code`
from `hsots_new`.`tsys_role` `r`
where (`r`.`approval_status` is null or `r`.`approval_status` <> '1')
  and `r`.`role_status` = '1'
union
select `ru`.`role_code`  AS `role_code`,
       `r`.`role_name`   AS `role_name`,
       `ru`.`right_flag` AS `right_flag`,
       `ru`.`user_code`  AS `user_id`,
       `r`.`role_order`  AS `role_order`,
       `r`.`tenant_id`   AS `tenant_id`,
       `r`.`kind_code`   AS `kind_code`
from `hsots_new`.`tsys_role_user` `ru`
         join `hsots_new`.`tsys_role` `r`
where `r`.`role_code` = `ru`.`role_code`
  and `ru`.`right_flag` = '2'
  and (`r`.`approval_status` is null or `r`.`approval_status` <> '1')
  and `r`.`role_status` = '1'
union
select `r`.`role_code`  AS `role_code`,
       `r`.`role_name`  AS `role_name`,
       '2'              AS `right_flag`,
       `r`.`creator`    AS `user_id`,
       `r`.`role_order` AS `role_order`,
       `r`.`tenant_id`  AS `tenant_id`,
       `r`.`kind_code`  AS `kind_code`
from `hsots_new`.`tsys_role` `r`
where (`r`.`approval_status` is null or `r`.`approval_status` <> '1')
  and `r`.`role_status` = '1';


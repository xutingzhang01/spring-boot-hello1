create definer = hs@`%` view user_pos_view as
select distinct `x0`.`position_code` AS `position_code`,
                `x0`.`position_name` AS `position_name`,
                `x0`.`parent_code`   AS `parent_code`,
                `x0`.`org_id`        AS `org_id`,
                `x0`.`role_code`     AS `role_code`,
                `x0`.`position_path` AS `position_path`,
                `x0`.`remark`        AS `remark`,
                `x0`.`EXT_FIELD_1`   AS `ext_field_1`,
                `x0`.`EXT_FIELD_2`   AS `ext_field_2`,
                `x0`.`EXT_FIELD_3`   AS `ext_field_3`,
                `x1`.`user_id`       AS `user_id`
from (`hsots_new`.`tsys_position` `x0` left join `hsots_new`.`tsys_pos_user` `x1`
      on (`x1`.`position_code` = `x0`.`position_code`));

-- comment on column user_pos_view.position_code not supported: 岗位编号

-- comment on column user_pos_view.position_name not supported: 岗位名称

-- comment on column user_pos_view.parent_code not supported: 上级岗位编号

-- comment on column user_pos_view.org_id not supported: 所属组织

-- comment on column user_pos_view.role_code not supported: 角色编号

-- comment on column user_pos_view.position_path not supported: 岗位内码

-- comment on column user_pos_view.ext_field_1 not supported: 扩展字段1

-- comment on column user_pos_view.ext_field_2 not supported: 扩展字段2

-- comment on column user_pos_view.ext_field_3 not supported: 扩展字段3

-- comment on column user_pos_view.user_id not supported: 用户代码


create
    definer = hs@`%` procedure del_show_config_field(IN showconfigcode varchar(50), IN showconfigfieldname varchar(50))
label:BEGIN
	delete from ot_tshowconfigfield where vc_sc_field_name = showconfigfieldname and vc_sc_id = (select vc_sc_id from ot_tshowconfig where vc_sc_code = showconfigcode);
	COMMIT ;
end;


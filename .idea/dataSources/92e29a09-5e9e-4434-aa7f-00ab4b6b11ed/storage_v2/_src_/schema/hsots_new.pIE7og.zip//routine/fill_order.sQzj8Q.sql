create
    definer = hs@`%` procedure fill_order()
BEGIN
	DECLARE no_more_record INT default 0;
	DECLARE i DECIMAL(10,0);
	DECLARE keyNO DECIMAL(10,0);
	DECLARE keyValue VARCHAR(12);
	DECLARE cur_record CURSOR FOR
	SELECT L_KEY_NO,VC_KEY_VALUE FROM ot_tdictionary
	GROUP BY L_KEY_NO,VC_KEY_VALUE
	ORDER BY L_KEY_NO,VC_KEY_VALUE;
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET no_more_record = 1;
	OPEN cur_record;
	SET i = 0;
	WHILE no_more_record != 1 DO
	FETCH cur_record INTO keyNO,keyValue;
		IF keyValue = '#' THEN
			SET i = 0;
		ELSE
			SET i = i + 1;
		END IF;
		UPDATE ot_tdictionary SET L_ORDER = i
			WHERE L_KEY_NO = keyNO AND VC_KEY_VALUE = keyValue;
	END WHILE;
	CLOSE cur_record;
END;


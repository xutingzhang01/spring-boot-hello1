create
    definer = hs@`%` procedure add_show_config_field(IN VC_SC_FIELD_ID varchar(32), IN VC_SC_ID varchar(32),
                                                     IN VC_SC_FIELD_NAME varchar(50), IN VC_SC_FIELD_LABEL varchar(50),
                                                     IN VC_SC_FIELD_TYPE varchar(50), IN VC_SC_FIELD_MODE varchar(50),
                                                     IN VC_SC_FIELD_FORMAT varchar(50), IN EN_SC_FIELD_SORT decimal(8),
                                                     IN EN_SC_FIELD_WIDTH decimal(8), IN EN_SC_FIELD_HEIGHT decimal(8),
                                                     IN VC_SC_FIELD_CATEGORY varchar(30), IN C_SC_FIELD_EDITABLE char,
                                                     IN C_SC_FIELD_ORDERABLE char, IN C_SC_FIELD_VISIBLE char,
                                                     IN C_SC_FIELD_FIXABLE char, IN C_SC_FIELD_FILTER_TYPE char,
                                                     IN C_SC_FIELD_GROUPABLE char,
                                                     IN VC_SC_FIELD_VALUE_FROM varchar(200),
                                                     IN C_SC_FIELD_LOAD_TYPE char,
                                                     IN VC_SC_FIELD_DEFAULT_VALUE varchar(500),
                                                     IN VC_SC_FIELD_RULES varchar(500),
                                                     IN C_SC_FIELD_MESSAGE varchar(500), IN C_SC_FIELD_VALUE_TYPE char)
BEGIN
	declare t_total_config int default 0;
	declare t_total_config_field int default 0;
	
	-- chaxun 
	select count(*) into t_total_config from ot_tshowconfig t where t.VC_SC_ID = VC_SC_ID;
	if t_total_config > 0 then
		select count(*) into t_total_config_field from ot_tshowconfigfield t where t.VC_SC_FIELD_ID = VC_SC_FIELD_ID;
		if t_total_config_field <= 0 then
			insert into ot_tshowconfigfield(VC_SC_FIELD_ID, VC_SC_ID, VC_SC_FIELD_NAME, VC_SC_FIELD_LABEL,VC_SC_FIELD_TYPE,  VC_SC_FIELD_MODE, VC_SC_FIELD_FORMAT, EN_SC_FIELD_SORT, EN_SC_FIELD_WIDTH, EN_SC_FIELD_HEIGHT, VC_SC_FIELD_CATEGORY, C_SC_FIELD_EDITABLE, C_SC_FIELD_ORDERABLE, C_SC_FIELD_VISIBLE, C_SC_FIELD_FIXABLE, C_SC_FIELD_FILTER_TYPE, C_SC_FIELD_GROUPABLE, VC_SC_FIELD_VALUE_FROM, C_SC_FIELD_LOAD_TYPE, VC_SC_FIELD_DEFAULT_VALUE, VC_SC_FIELD_RULES, C_SC_FIELD_MESSAGE, C_SC_FIELD_VALUE_TYPE)
			values(VC_SC_FIELD_ID, VC_SC_ID, VC_SC_FIELD_NAME, VC_SC_FIELD_LABEL,VC_SC_FIELD_TYPE,  VC_SC_FIELD_MODE, VC_SC_FIELD_FORMAT, EN_SC_FIELD_SORT, EN_SC_FIELD_WIDTH, EN_SC_FIELD_HEIGHT, VC_SC_FIELD_CATEGORY, C_SC_FIELD_EDITABLE, C_SC_FIELD_ORDERABLE, C_SC_FIELD_VISIBLE, C_SC_FIELD_FIXABLE, C_SC_FIELD_FILTER_TYPE, C_SC_FIELD_GROUPABLE, VC_SC_FIELD_VALUE_FROM, C_SC_FIELD_LOAD_TYPE, VC_SC_FIELD_DEFAULT_VALUE, VC_SC_FIELD_RULES, C_SC_FIELD_MESSAGE, C_SC_FIELD_VALUE_TYPE);
		end if;
	end if;
	commit;
END;


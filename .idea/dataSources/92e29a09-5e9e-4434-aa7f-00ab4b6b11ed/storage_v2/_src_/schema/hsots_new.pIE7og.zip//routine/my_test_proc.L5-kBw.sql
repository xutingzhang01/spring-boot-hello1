create
    definer = hs@`%` procedure my_test_proc()
begin
    declare v_rowcount integer;
select count(1) into v_rowcount
from OT_TDICTIONARY where vc_tenant_id = '10000' and l_key_no = 5342;
if v_rowcount = 0 then
INSERT INTO OT_TDICTIONARY (VC_TENANT_ID, L_KEY_NO, VC_KEY_VALUE, VC_CAPTION, C_MODIFY, VC_MEMO, VC_TRANSLATION, L_ORDER, GMT_CREATE, GMT_MODIFIED, C_DIC_USED_STATE) VALUES ('10000', 5342, '#', '信息披露代办状态', null, null, null, 0, null, null, '1');
INSERT INTO OT_TDICTIONARY (VC_TENANT_ID, L_KEY_NO, VC_KEY_VALUE, VC_CAPTION, C_MODIFY, VC_MEMO, VC_TRANSLATION, L_ORDER, GMT_CREATE, GMT_MODIFIED, C_DIC_USED_STATE) VALUES ('10000', 5342, '0', '未处理', null, null, null, 1, null, null, '1');
INSERT INTO OT_TDICTIONARY (VC_TENANT_ID, L_KEY_NO, VC_KEY_VALUE, VC_CAPTION, C_MODIFY, VC_MEMO, VC_TRANSLATION, L_ORDER, GMT_CREATE, GMT_MODIFIED, C_DIC_USED_STATE) VALUES ('10000', 5342, '1', '已处理', null, null, null, 2, null, null, '1');
end if;
end;


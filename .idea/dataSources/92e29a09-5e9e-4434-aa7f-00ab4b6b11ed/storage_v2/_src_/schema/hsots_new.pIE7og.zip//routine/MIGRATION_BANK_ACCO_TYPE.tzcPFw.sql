create
    definer = hs@`%` function MIGRATION_BANK_ACCO_TYPE(JSON varchar(500)) returns varchar(500)
BEGIN
	DECLARE t_info VARCHAR(500) DEFAULT '执行成功!';
	declare old_pro varchar(4000);
    declare temp_id varchar(20);
	DECLARE flag INT DEFAULT 0;
	DECLARE s_list CURSOR FOR (SELECT t.VC_BANK_ACCO_ID,t.VC_CAPITAL_INFO FROM ot_tbank_liquidate_acco t WHERE t.VC_TENANT_ID='10000');
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET flag = 1;

open s_list;
fetch s_list into temp_id, old_pro;
while flag <> 1 do
						set @temp_value = POSITION(JSON in old_pro);
            set @temp_s = substring(old_pro,@temp_value+15,1);
update ot_tbank_liquidate_acco set VC_BANK_ACCO_TYPE=@temp_s where VC_BANK_ACCO_ID=temp_id;
fetch s_list into temp_id, old_pro;
end while;
close s_list;
RETURN t_info;
END;


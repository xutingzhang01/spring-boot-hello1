create
    definer = hs@`%` procedure add_show_config(IN VC_SC_ID varchar(32), IN VC_SC_GROUP_ID varchar(32),
                                               IN VC_SC_CODE varchar(50), IN VC_SC_NAME varchar(50),
                                               IN VC_SC_VERSION varchar(50), IN C_SC_SERVICE_TYPE char,
                                               IN VC_SC_SERVICES varchar(500), IN VC_SC_TYPE varchar(15))
BEGIN
		declare t_total int default 0;
		declare t_total_config int default 0;

		-- 查询是否存在这个显示配置组
		select count(*) into t_total from ot_tshowconfiggroup t where t.VC_SC_GROUP_ID = VC_SC_GROUP_ID;

		if t_total > 0 then
			select count(*) into t_total_config from ot_tshowconfig t where t.VC_SC_ID = VC_SC_ID;
			if t_total_config <= 0 then
				insert into ot_tshowconfig(VC_SC_ID, VC_SC_GROUP_ID, VC_SC_CODE,VC_SC_NAME, VC_SC_VERSION, C_SC_SERVICE_TYPE, VC_SC_SERVICES, VC_SC_TYPE)
				values(VC_SC_ID, VC_SC_GROUP_ID, VC_SC_CODE,VC_SC_NAME, VC_SC_VERSION, C_SC_SERVICE_TYPE, VC_SC_SERVICES, VC_SC_TYPE);
			end if;
		end if;
		commit;
END;


create
    definer = hs@`%` procedure update_show_config_field(IN showconfigcode varchar(50),
                                                        IN showconfigfieldname varchar(50), IN columnname varchar(100),
                                                        IN columnvalue varchar(200))
label:BEGIN
	if lower(columnname) = 'vc_sc_field_name' then
     update ot_tshowconfigfield set vc_sc_field_name = columnvalue where vc_sc_field_name = showconfigfieldname and vc_sc_id = (select vc_sc_id from ot_tshowconfig where vc_sc_code = showconfigcode);
    elseif lower(columnname) = 'vc_sc_field_label' then
     update ot_tshowconfigfield set vc_sc_field_label = columnvalue where vc_sc_field_name = showconfigfieldname and vc_sc_id = (select vc_sc_id from ot_tshowconfig where vc_sc_code = showconfigcode);
    elseif lower(columnname) = 'vc_sc_field_type' then
     update ot_tshowconfigfield set vc_sc_field_type = columnvalue where vc_sc_field_name = showconfigfieldname and vc_sc_id = (select vc_sc_id from ot_tshowconfig where vc_sc_code = showconfigcode);
	elseif lower(columnname) = 'vc_sc_field_rules' then
     update ot_tshowconfigfield set vc_sc_field_rules = columnvalue where vc_sc_field_name = showconfigfieldname and vc_sc_id = (select vc_sc_id from ot_tshowconfig where vc_sc_code = showconfigcode);
	elseif lower(columnname) = 'c_sc_field_message' then
     update ot_tshowconfigfield set c_sc_field_message = columnvalue where vc_sc_field_name = showconfigfieldname and vc_sc_id = (select vc_sc_id from ot_tshowconfig where vc_sc_code = showconfigcode);
	elseif lower(columnname) = 'vc_sc_field_value_from' then
     update ot_tshowconfigfield set vc_sc_field_value_from = columnvalue where vc_sc_field_name = showconfigfieldname and vc_sc_id = (select vc_sc_id from ot_tshowconfig where vc_sc_code = showconfigcode);
	elseif lower(columnname) = 'en_sc_field_sort' then
     update ot_tshowconfigfield set en_sc_field_sort = columnvalue where vc_sc_field_name = showconfigfieldname and vc_sc_id = (select vc_sc_id from ot_tshowconfig where vc_sc_code = showconfigcode);
	elseif lower(columnname) = 'vc_sc_field_mode' then
     update ot_tshowconfigfield set vc_sc_field_mode = columnvalue where vc_sc_field_name = showconfigfieldname and vc_sc_id = (select vc_sc_id from ot_tshowconfig where vc_sc_code = showconfigcode);
	elseif lower(columnname) = 'vc_sc_field_format' then
     update ot_tshowconfigfield set vc_sc_field_format = columnvalue where vc_sc_field_name = showconfigfieldname and vc_sc_id = (select vc_sc_id from ot_tshowconfig where vc_sc_code = showconfigcode);
	elseif lower(columnname) = 'en_sc_field_width' then
     update ot_tshowconfigfield set en_sc_field_width = columnvalue where vc_sc_field_name = showconfigfieldname and vc_sc_id = (select vc_sc_id from ot_tshowconfig where vc_sc_code = showconfigcode);
	elseif lower(columnname) = 'en_sc_field_height' then
     update ot_tshowconfigfield set en_sc_field_height = columnvalue where vc_sc_field_name = showconfigfieldname and vc_sc_id = (select vc_sc_id from ot_tshowconfig where vc_sc_code = showconfigcode);
	elseif lower(columnname) = 'vc_sc_field_category' then
     update ot_tshowconfigfield set vc_sc_field_category = columnvalue where vc_sc_field_name = showconfigfieldname and vc_sc_id = (select vc_sc_id from ot_tshowconfig where vc_sc_code = showconfigcode);
	elseif lower(columnname) = 'c_sc_field_editable' then
     update ot_tshowconfigfield set c_sc_field_editable = columnvalue where vc_sc_field_name = showconfigfieldname and vc_sc_id = (select vc_sc_id from ot_tshowconfig where vc_sc_code = showconfigcode);
	elseif lower(columnname) = 'c_sc_field_orderable' then
     update ot_tshowconfigfield set c_sc_field_orderable = columnvalue where vc_sc_field_name = showconfigfieldname and vc_sc_id = (select vc_sc_id from ot_tshowconfig where vc_sc_code = showconfigcode);
	elseif lower(columnname) = 'c_sc_field_visible' then
     update ot_tshowconfigfield set c_sc_field_visible = columnvalue where vc_sc_field_name = showconfigfieldname and vc_sc_id = (select vc_sc_id from ot_tshowconfig where vc_sc_code = showconfigcode);
	elseif lower(columnname) = 'c_sc_field_fixable' then
     update ot_tshowconfigfield set c_sc_field_fixable = columnvalue where vc_sc_field_name = showconfigfieldname and vc_sc_id = (select vc_sc_id from ot_tshowconfig where vc_sc_code = showconfigcode);
	elseif lower(columnname) = 'c_sc_field_filter_type' then
     update ot_tshowconfigfield set c_sc_field_filter_type = columnvalue where vc_sc_field_name = showconfigfieldname and vc_sc_id = (select vc_sc_id from ot_tshowconfig where vc_sc_code = showconfigcode);
	elseif lower(columnname) = 'vc_sc_field_default_value' then
     update ot_tshowconfigfield set vc_sc_field_default_value = columnvalue where vc_sc_field_name = showconfigfieldname and vc_sc_id = (select vc_sc_id from ot_tshowconfig where vc_sc_code = showconfigcode);
	elseif lower(columnname) = 'c_sc_field_value_type' then
     update ot_tshowconfigfield set c_sc_field_value_type = columnvalue where vc_sc_field_name = showconfigfieldname and vc_sc_id = (select vc_sc_id from ot_tshowconfig where vc_sc_code = showconfigcode);
    end if;
	COMMIT ;
end;


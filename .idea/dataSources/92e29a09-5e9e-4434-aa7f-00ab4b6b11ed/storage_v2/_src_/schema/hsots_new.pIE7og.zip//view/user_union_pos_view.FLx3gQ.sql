create definer = hs@`%` view user_union_pos_view as
select `u`.`user_id`       AS `user_id`,
       `u`.`user_name`     AS `user_name`,
       `u`.`user_status`   AS `user_status`,
       `p`.`position_code` AS `position_code`,
       `p`.`position_name` AS `position_name`,
       `u`.`org_id`        AS `org_id`,
       `p`.`org_id`        AS `pos_org_id`
from `hsots_new`.`tsys_position` `p`
         join `hsots_new`.`tsys_user` `u`
where `u`.`approval_status` is null
   or `u`.`approval_status` <> '1';

-- comment on column user_union_pos_view.user_id not supported: 用户代码

-- comment on column user_union_pos_view.user_status not supported: 用于表示此用户状态取数据字典[SYS_BIZ_USER_STATUS]0-正常1-注销2-禁用

-- comment on column user_union_pos_view.position_code not supported: 岗位编号

-- comment on column user_union_pos_view.position_name not supported: 岗位名称

-- comment on column user_union_pos_view.org_id not supported: 所属组织机构

-- comment on column user_union_pos_view.pos_org_id not supported: 所属组织


create
    definer = hs@`%` procedure f_show_config_group(IN opertate_type varchar(32), IN vc_code varchar(200),
                                                   IN vc_name varchar(200), IN vc_version varchar(200))
label:BEGIN
	DECLARE t_id varchar(32);
	DECLARE t_total int;
	DECLARE vc_tenant_id varchar(32) default '10000';

	select count(*) into t_total from OT_TSHOWCONFIGGROUP t where t.VC_SC_GROUP_CODE=vc_code;

	if t_total<=0 and (opertate_type='2' or opertate_type='3') then
	  select concat('show_config_group不存在:',vc_code);
	  leave label;
	elseif t_total >0 then
		select t.VC_SC_GROUP_ID into t_id from OT_TSHOWCONFIGGROUP t where t.VC_SC_GROUP_CODE=vc_code;
	end if;

  if opertate_type = '1' then
    if t_total<=0 then
			insert into OT_TSHOWCONFIGGROUP values(null,vc_code,vc_name,vc_version,vc_tenant_id);
		else
			select concat('show_config_group已存在:',vc_code);
	    leave label;
		end if;
	elseif opertate_type='2' then
    delete from OT_TSHOWCONFIGGROUP where VC_SC_GROUP_ID=t_id;
		delete from OT_TSHOWCONFIGFIELD where VC_SC_ID in (select VC_SC_ID from OT_TSHOWCONFIG t where t.VC_SC_GROUP_ID = t_id);
    delete from OT_TSHOWCONFIG where VC_SC_GROUP_ID = t_id;
  elseif  opertate_type = '3' then
    update OT_TSHOWCONFIGGROUP set VC_SC_GROUP_CODE=vc_code,VC_SC_GROUP_NAME=vc_name,
    VC_SC_GROUP_VERSION=vc_version,VC_TENANT_ID=vc_tenant_id  where VC_SC_GROUP_ID=t_id;
  end if;
	commit;
END;


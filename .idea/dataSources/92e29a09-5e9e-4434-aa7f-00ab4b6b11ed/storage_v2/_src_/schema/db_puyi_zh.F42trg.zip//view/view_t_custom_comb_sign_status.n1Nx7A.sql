create definer = hs@`%` view view_t_custom_comb_sign_status as
select `db_puyi_zh`.`t_custom_comb_sign_status`.`CLIENT_ID` AS `CLIENT_ID`
from `db_puyi_zh`.`t_custom_comb_sign_status`
where `db_puyi_zh`.`t_custom_comb_sign_status`.`SIGN_STATUS` = '1'
union
select `db_puyi_zh`.`t_custom_comb_sign_status_his`.`CLIENT_ID` AS `CLIENT_ID`
from `db_puyi_zh`.`t_custom_comb_sign_status_his`
where `db_puyi_zh`.`t_custom_comb_sign_status_his`.`SIGN_STATUS` = '1';


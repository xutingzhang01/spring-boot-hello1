create
    definer = hs@`%` procedure my_test_proc()
begin
 declare v_rowcount integer ;
    select count(1) into v_rowcount from bg_tsysparameter where c_item = 'BGW_REGISTER_NEED_DS_CUSTNO';
    if v_rowcount = 0 then
		insert into bg_tsysparameter (C_CLASS, C_ITEM, C_VALUE, C_MODIFY, C_DESCRIBE, C_CRYPTFLAG, C_TYPE, C_VALUEBOUND, C_SHOWCLASS, C_SHOWSUBCLASS, L_ORDER, C_SYSNAME)
    values ('SALE', 'BGW_REGISTER_NEED_DS_CUSTNO', '0', '0', '注册是否需要调用获取直销客户编号', '0', null, '0：不需要获取，1：需要获取', '', '', null, '业务网关');
 end if;
end;


create
    definer = hs@`%` function func_current_val(seq_name varchar(100)) returns int(20) deterministic
BEGIN
    DECLARE value INTEGER;
    SET value = 0;
    SELECT L_CURRENT_VALUE
    INTO value
    FROM T_SUS_SEQUENCE
    WHERE VC_NAME = upper(seq_name);
    RETURN value;
END;


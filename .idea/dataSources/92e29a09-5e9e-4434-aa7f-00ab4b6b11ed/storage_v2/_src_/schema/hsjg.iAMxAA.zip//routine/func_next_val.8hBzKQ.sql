create
    definer = hs@`%` function func_next_val(seq_name varchar(100)) returns int(20) deterministic
BEGIN
    UPDATE T_SUS_SEQUENCE
    SET L_CURRENT_VALUE = L_CURRENT_VALUE + L_INCREMENTS
    WHERE VC_NAME = upper(seq_name);
    RETURN func_current_val(seq_name);
END;


create
    definer = root@`%` procedure batch_insert(IN fromTable varchar(64), IN targetTable varchar(64), IN limitNum int)
BEGIN
		  -- 参数 
			-- fromTable 源表 （带实例名）
			-- targetTable 目标表（带实例名）
			-- limitNum 每批次插入数量

      declare startQuotient int default 0;
			declare startLimit int default 0;
			
			set @ct = CONCAT("select COUNT(1) into @totalNum from ",fromTable,";");
      PREPARE stmt1 FROM @ct;
      EXECUTE stmt1;
      DEALLOCATE PREPARE stmt1;

			set @quotient=  ROUND(@totalNum/limitNum,0);
      
      WHILE startQuotient <= @quotient DO
      set @insertSql = CONCAT("insert into ",targetTable," SELECT * from ",fromTable," limit ",startLimit," , ",limitNum,';');
			PREPARE stmt1 FROM @insertSql;
			EXECUTE stmt1;
			set startLimit = startLimit + limitNum;
			set startQuotient = startQuotient + 1;
			SELECT sleep(0.2);
      END WHILE;
END;


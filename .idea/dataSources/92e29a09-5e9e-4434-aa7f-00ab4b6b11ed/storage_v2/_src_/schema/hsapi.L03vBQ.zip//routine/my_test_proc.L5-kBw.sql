create
    definer = hs@`%` procedure my_test_proc()
begin
declare
  v_rowcount integer;
    select count(1) into v_rowcount from (select * from information_schema.table_constraints where table_schema = (SELECT DATABASE())) t
    where table_name = upper('TSENDMSGRECORD') and constraint_type = 'PRIMARY KEY';
    if v_rowcount = 1 then
    alter table TSENDMSGRECORD drop primary key;
    ALTER TABLE TSENDMSGRECORD  ADD PRIMARY KEY(VC_SENDKEY, VC_SENDTIME);
  end if;
  if v_rowcount = 0 then
  ALTER TABLE TSENDMSGRECORD  ADD PRIMARY KEY(VC_SENDKEY, VC_SENDTIME);
    end if;
end;


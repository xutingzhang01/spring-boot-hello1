create
    definer = hs@`%` function nextval(seq_name varchar(100)) returns int deterministic
BEGIN
	UPDATE sequence SET current_value = current_value + increment WHERE NAME = upper(seq_name) ;
	RETURN currval (seq_name) ;
END;


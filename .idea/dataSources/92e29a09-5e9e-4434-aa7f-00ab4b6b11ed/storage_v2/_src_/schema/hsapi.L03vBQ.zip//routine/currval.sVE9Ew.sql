create
    definer = hs@`%` function currval(seq_name varchar(100)) returns int deterministic reads sql data
BEGIN
	DECLARE VALUE INTEGER ;
	SET VALUE = 0 ; 
	SELECT current_value INTO VALUE FROM sequence WHERE NAME = upper(seq_name);
	RETURN VALUE ;
END;


create
    definer = hs@`%` procedure proc_add_sequence(IN sequenceName varchar(100), IN currentValue int, IN increments int)
BEGIN
    SELECT COUNT(*) INTO @cnt from T_SUS_SEQUENCE where VC_NAME = upper(sequenceName);
    IF @cnt = 0 THEN
        insert into T_SUS_SEQUENCE (VC_NAME, L_CURRENT_VALUE, L_INCREMENTS)
        values (upper(sequenceName), currentValue, increments);
        commit;
    END IF;
END;


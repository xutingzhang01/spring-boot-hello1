create
    definer = hs@`%` procedure init_data()
begin
    declare icount int unsigned default 0;
select count(1) into icount from T_SUS_MENU_ROLE;
if icount = 0 then
        insert into T_SUS_MENU_ROLE (VC_ROLE, VC_ROLE_NAME, VC_MENU_ID)
        values ('A', '账户权限', '1');
insert into T_SUS_MENU_ROLE (VC_ROLE, VC_ROLE_NAME, VC_MENU_ID)
values ('A', '账户权限', '11');
insert into T_SUS_MENU_ROLE (VC_ROLE, VC_ROLE_NAME, VC_MENU_ID)
values ('A', '账户权限', '12');
insert into T_SUS_MENU_ROLE (VC_ROLE, VC_ROLE_NAME, VC_MENU_ID)
values ('A', '账户权限', '13');
insert into T_SUS_MENU_ROLE (VC_ROLE, VC_ROLE_NAME, VC_MENU_ID)
values ('A', '账户权限', '14');
insert into T_SUS_MENU_ROLE (VC_ROLE, VC_ROLE_NAME, VC_MENU_ID)
values ('A', '账户权限', '16');
insert into T_SUS_MENU_ROLE (VC_ROLE, VC_ROLE_NAME, VC_MENU_ID)
values ('A', '账户权限', '161');
insert into T_SUS_MENU_ROLE (VC_ROLE, VC_ROLE_NAME, VC_MENU_ID)
values ('A', '账户权限', '162');
insert into T_SUS_MENU_ROLE (VC_ROLE, VC_ROLE_NAME, VC_MENU_ID)
values ('A', '账户权限', '163');
insert into T_SUS_MENU_ROLE (VC_ROLE, VC_ROLE_NAME, VC_MENU_ID)
values ('A', '账户权限', '4');
insert into T_SUS_MENU_ROLE (VC_ROLE, VC_ROLE_NAME, VC_MENU_ID)
values ('A', '账户权限', '41');
insert into T_SUS_MENU_ROLE (VC_ROLE, VC_ROLE_NAME, VC_MENU_ID)
values ('Q', '查询权限', '3');
insert into T_SUS_MENU_ROLE (VC_ROLE, VC_ROLE_NAME, VC_MENU_ID)
values ('Q', '查询权限', '31');
insert into T_SUS_MENU_ROLE (VC_ROLE, VC_ROLE_NAME, VC_MENU_ID)
values ('Q', '查询权限', '32');
insert into T_SUS_MENU_ROLE (VC_ROLE, VC_ROLE_NAME, VC_MENU_ID)
values ('Q', '查询权限', '33');
insert into T_SUS_MENU_ROLE (VC_ROLE, VC_ROLE_NAME, VC_MENU_ID)
values ('Q', '查询权限', '35');
insert into T_SUS_MENU_ROLE (VC_ROLE, VC_ROLE_NAME, VC_MENU_ID)
values ('T', '交易权限', '1');
insert into T_SUS_MENU_ROLE (VC_ROLE, VC_ROLE_NAME, VC_MENU_ID)
values ('T', '交易权限', '11');
insert into T_SUS_MENU_ROLE (VC_ROLE, VC_ROLE_NAME, VC_MENU_ID)
values ('T', '交易权限', '12');
insert into T_SUS_MENU_ROLE (VC_ROLE, VC_ROLE_NAME, VC_MENU_ID)
values ('T', '交易权限', '13');
insert into T_SUS_MENU_ROLE (VC_ROLE, VC_ROLE_NAME, VC_MENU_ID)
values ('T', '交易权限', '14');
insert into T_SUS_MENU_ROLE (VC_ROLE, VC_ROLE_NAME, VC_MENU_ID)
values ('T', '交易权限', '16');
insert into T_SUS_MENU_ROLE (VC_ROLE, VC_ROLE_NAME, VC_MENU_ID)
values ('T', '交易权限', '161');
insert into T_SUS_MENU_ROLE (VC_ROLE, VC_ROLE_NAME, VC_MENU_ID)
values ('T', '交易权限', '162');
insert into T_SUS_MENU_ROLE (VC_ROLE, VC_ROLE_NAME, VC_MENU_ID)
values ('T', '交易权限', '163');
insert into T_SUS_MENU_ROLE (VC_ROLE, VC_ROLE_NAME, VC_MENU_ID)
values ('T', '交易权限', '17');
insert into T_SUS_MENU_ROLE (VC_ROLE, VC_ROLE_NAME, VC_MENU_ID)
values ('T', '交易权限', '2');
insert into T_SUS_MENU_ROLE (VC_ROLE, VC_ROLE_NAME, VC_MENU_ID)
values ('T', '交易权限', '21');
insert into T_SUS_MENU_ROLE (VC_ROLE, VC_ROLE_NAME, VC_MENU_ID)
values ('T', '交易权限', '22');
insert into T_SUS_MENU_ROLE (VC_ROLE, VC_ROLE_NAME, VC_MENU_ID)
values ('T', '交易权限', '23');
insert into T_SUS_MENU_ROLE (VC_ROLE, VC_ROLE_NAME, VC_MENU_ID)
values ('T', '交易权限', '24');
insert into T_SUS_MENU_ROLE (VC_ROLE, VC_ROLE_NAME, VC_MENU_ID)
values ('C', '审核权限', '1');
insert into T_SUS_MENU_ROLE (VC_ROLE, VC_ROLE_NAME, VC_MENU_ID)
values ('C', '审核权限', '11');
insert into T_SUS_MENU_ROLE (VC_ROLE, VC_ROLE_NAME, VC_MENU_ID)
values ('C', '审核权限', '12');
insert into T_SUS_MENU_ROLE (VC_ROLE, VC_ROLE_NAME, VC_MENU_ID)
values ('C', '审核权限', '13');
insert into T_SUS_MENU_ROLE (VC_ROLE, VC_ROLE_NAME, VC_MENU_ID)
values ('C', '审核权限', '16');
insert into T_SUS_MENU_ROLE (VC_ROLE, VC_ROLE_NAME, VC_MENU_ID)
values ('C', '审核权限', '161');
insert into T_SUS_MENU_ROLE (VC_ROLE, VC_ROLE_NAME, VC_MENU_ID)
values ('C', '审核权限', '162');
insert into T_SUS_MENU_ROLE (VC_ROLE, VC_ROLE_NAME, VC_MENU_ID)
values ('C', '审核权限', '163');
insert into T_SUS_MENU_ROLE (VC_ROLE, VC_ROLE_NAME, VC_MENU_ID)
values ('C', '审核权限', '17');
insert into T_SUS_MENU_ROLE (VC_ROLE, VC_ROLE_NAME, VC_MENU_ID)
values ('C', '审核权限', '3');
insert into T_SUS_MENU_ROLE (VC_ROLE, VC_ROLE_NAME, VC_MENU_ID)
values ('C', '审核权限', '31');
insert into T_SUS_MENU_ROLE (VC_ROLE, VC_ROLE_NAME, VC_MENU_ID)
values ('C', '审核权限', '33');
insert into T_SUS_MENU_ROLE (VC_ROLE, VC_ROLE_NAME, VC_MENU_ID)
values ('C', '审核权限', '32');
insert into T_SUS_MENU_ROLE (VC_ROLE, VC_ROLE_NAME, VC_MENU_ID)
values ('C', '审核权限', '35');
insert into T_SUS_MENU_ROLE (VC_ROLE, VC_ROLE_NAME, VC_MENU_ID)
values ('C', '审核权限', '5');
insert into T_SUS_MENU_ROLE (VC_ROLE, VC_ROLE_NAME, VC_MENU_ID)
values ('C', '审核权限', '51');
commit;
end if;
end;


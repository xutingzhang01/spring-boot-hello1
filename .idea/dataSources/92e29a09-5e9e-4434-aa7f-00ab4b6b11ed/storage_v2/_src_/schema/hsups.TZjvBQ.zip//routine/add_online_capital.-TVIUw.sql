create
    definer = hs@`%` procedure add_online_capital()
begin
declare iCount Integer;
  select count(*) into iCount from tsysparameter where c_item='UPS_ONLINE_PAGE_CAPITALMODE' and C_CLASS='UPS';
	if iCount = 0 then
		INSERT INTO tsysparameter(C_CLASS, C_ITEM, C_VALUE, C_MODIFY, C_DESCRIBE) VALUES ('UPS', 'UPS_ONLINE_PAGE_CAPITALMODE', null, '0', '支持在线支付功能的渠道');
  end if;
  commit;
end;


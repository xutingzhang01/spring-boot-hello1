create
    definer = hs@`%` function to_date(str tinytext, format tinytext) returns date deterministic
begin
    declare c date;
    declare mysqlFormat TINYTEXT;

    case when format = 'yyyyMMdd' then
        set mysqlFormat = '%Y%m%d';
        when format = 'yyyy-MM-dd' then
            set mysqlFormat = '%Y-%m-%d';
        when format = 'yyyymmddhh24miss' then
            set mysqlFormat = '%Y%m%d%H%i%s';
        else
            set mysqlFormat = '0';
        end case;

    select str_to_date(str , mysqlFormat) into c;
    return c;
end;


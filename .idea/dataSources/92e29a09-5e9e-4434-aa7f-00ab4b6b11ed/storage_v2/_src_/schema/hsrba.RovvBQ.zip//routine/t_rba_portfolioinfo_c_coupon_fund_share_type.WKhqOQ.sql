create
    definer = hs@`%` procedure t_rba_portfolioinfo_c_coupon_fund_share_type()
BEGIN
IF NOT EXISTS (SELECT * FROM information_schema.columns WHERE table_schema = DATABASE()  AND table_name = 'T_RBA_PORTFOLIOINFO'
AND column_name = 'C_COUPON_FUND_SHARE_TYPE') THEN
    ALTER TABLE T_RBA_PORTFOLIOINFO ADD COLUMN C_COUPON_FUND_SHARE_TYPE  CHAR(1);
END IF;
END;


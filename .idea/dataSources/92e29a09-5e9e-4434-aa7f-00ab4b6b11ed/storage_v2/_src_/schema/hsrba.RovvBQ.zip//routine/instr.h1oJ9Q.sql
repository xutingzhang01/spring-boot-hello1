create
    definer = hs@`%` function instr(str1 tinytext, str2 tinytext) returns tinytext deterministic
begin
    declare c TINYTEXT;
    select locate(str2, str1) into c;
    return c;
end;


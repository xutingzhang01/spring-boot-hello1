create
    definer = hs@`%` function func_rba_current_val(seq_name varchar(50)) returns int
BEGIN
    DECLARE value INTEGER;
    SET value = 0;
    SELECT L_CURRENT_VALUE
    INTO value
    FROM t_rba_sequence
    WHERE VC_NAME = upper(seq_name);
    RETURN value;
END;


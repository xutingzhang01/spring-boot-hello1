create
    definer = hs@`%` procedure t_rba_portfolioinfo_vc_coupon_fund_code_change()
BEGIN
IF NOT EXISTS (SELECT * FROM information_schema.columns WHERE table_schema = DATABASE()  AND table_name = 'T_RBA_PORTFOLIOINFO'
AND column_name = 'VC_COUPON_FUND_CODE') THEN
    ALTER TABLE T_RBA_PORTFOLIOINFO ADD COLUMN VC_COUPON_FUND_CODE  CHAR(6);
END IF;
END;


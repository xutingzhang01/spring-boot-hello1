create
    definer = hs@`%` function nlnull2(str1 tinytext, str2 tinytext, str3 tinytext) returns tinytext deterministic
begin
    declare c TINYTEXT;
    select case when str1 is null then str3 when str1 = '' then str3 else str2 end into c;
    return c;
end;


create
    definer = hs@`%` procedure del_idx(IN p_tablename varchar(200), IN p_idxname varchar(200))
begin
DECLARE str VARCHAR(250);
  set @str=concat(' drop index ',p_idxname,' on ',p_tablename);
  set @hh = concat('select count(*) into @cnt from information_schema.statistics where table_name=\'',p_tablename, '\' and index_name=\'',p_idxname,'\' and table_schema=(select database())');
  PREPARE prehh FROM @hh;
  EXECUTE prehh ;
  if @cnt >0 then 
    PREPARE stmt FROM @str;
    EXECUTE stmt ;
  end if;
 
end;


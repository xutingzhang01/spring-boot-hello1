create
    definer = hs@`%` procedure columns_change()
BEGIN

IF EXISTS (select column_name  from information_schema.columns where table_name = 'PAYCHANNEL_TRADING_INFO' and column_name = 'VC_OTHER_AREA_NAME' and TABLE_SCHEMA = database() ) THEN
   ALTER TABLE PAYCHANNEL_TRADING_INFO MODIFY COLUMN VC_SUB_ACCO_NO VARCHAR(40) COMMENT '付款子账号编号';
END IF;

IF EXISTS (select column_name  from information_schema.columns where table_name = 'PAYCHANNEL_TRADING_INFO' and column_name = 'VC_OTHER_AREA_NAME' and TABLE_SCHEMA = database() ) THEN
   ALTER TABLE PAYCHANNEL_TRADING_INFO MODIFY COLUMN VC_OTHER_SUB_ACCO_NO VARCHAR(40) COMMENT '收款子账户编号';
END IF;

END;


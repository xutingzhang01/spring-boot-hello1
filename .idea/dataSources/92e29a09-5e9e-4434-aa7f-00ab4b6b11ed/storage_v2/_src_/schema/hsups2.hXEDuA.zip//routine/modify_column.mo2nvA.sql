create
    definer = hs@`%` procedure modify_column()
BEGIN
if exists (select * from information_schema.columns where table_schema in (select database()) and table_name='SUPERVISION_DATAS_INFO'
		and column_name='C_BANK_NO')
	then
   alter table SUPERVISION_DATAS_INFO modify C_BANK_NO varchar(20) NULL COMMENT '监管行编号';
	end
if;
end;


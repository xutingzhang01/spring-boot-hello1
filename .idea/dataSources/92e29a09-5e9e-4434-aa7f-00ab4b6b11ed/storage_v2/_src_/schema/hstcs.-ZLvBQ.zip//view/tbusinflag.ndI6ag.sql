create definer = hs@`%` view tbusinflag as
select `hstcs`.`tc_tbusinflag`.`C_SYS_GROUP`          AS `C_FLAG`,
       `hstcs`.`tc_tbusinflag`.`C_REQ_CODE`           AS `C_REQCODE`,
       `hstcs`.`tc_tbusinflag`.`C_CFM_CODE`           AS `C_CFMCODE`,
       `hstcs`.`tc_tbusinflag`.`C_INTERFACE_REQ_CODE` AS `C_INTERFACEREQCODE`,
       `hstcs`.`tc_tbusinflag`.`C_INTERFACE_CFM_CODE` AS `C_INTERFACECFMCODE`,
       `hstcs`.`tc_tbusinflag`.`VC_REQ_NAME`          AS `VC_REQNAME`,
       `hstcs`.`tc_tbusinflag`.`VC_CFM_NAME`          AS `VC_CFMNAME`,
       `hstcs`.`tc_tbusinflag`.`VC_REQ_NAME_EN`       AS `VC_REQNAME_EN`,
       `hstcs`.`tc_tbusinflag`.`VC_CFM_NAME_EN`       AS `VC_CFNAME_EN`
from `hstcs`.`tc_tbusinflag`;


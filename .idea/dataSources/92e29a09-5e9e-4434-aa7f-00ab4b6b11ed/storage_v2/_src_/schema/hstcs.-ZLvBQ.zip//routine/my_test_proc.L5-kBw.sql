create
    definer = hs@`%` procedure my_test_proc()
begin
    declare v_rowcount integer;
    select count(1) into v_rowcount from tc_tdictionary where l_key_no = 5448 and c_key_value='2';
    if v_rowcount = 0 then
        insert into tc_tdictionary (VC_TENANT_ID, L_KEY_NO, C_KEY_VALUE, C_CAPTION, C_MODIFY, L_ORDER,  C_DIC_USED_STATE)values ('10000', 5448, '2','允许交易，交易无需复核', '0', 3,  '1');
    end if;
end;


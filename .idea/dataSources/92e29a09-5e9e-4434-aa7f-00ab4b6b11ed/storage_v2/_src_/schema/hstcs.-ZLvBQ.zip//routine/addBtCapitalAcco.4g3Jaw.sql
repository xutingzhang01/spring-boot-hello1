create
    definer = hs@`%` procedure addBtCapitalAcco()
BEGIN

DECLARE v_rowcount INTEGER;

--  该变量用于标识是否还有数据需遍历
DECLARE flag INT DEFAULT 0;

--  创建一个变量用来存储遍历过程中的值
DECLARE tradeacco VARCHAR (40);

--  查询出需要遍历的数据集合
DECLARE idList CURSOR FOR (
	SELECT
		a.VC_TRADE_ACCO
	FROM
		tc_taccoinfo a,
		tc_taccobank b,
		tc_tcapitalacco c,
		tc_tchinaprnsresult k
	WHERE
		b.VC_BANK_ACCO = k.VC_BANK_ACCO
	AND a.VC_BANK_CARD_NO = c.VC_BANK_CARD_NO
	AND c.VC_BANK_CARD_NO = b.VC_BANK_CARD_NO
	AND c.VC_TRADE_ACCO = a.VC_TRADE_ACCO
);

--  查询是否有下一个数据，没有将标识设为1，相当于hasNext
DECLARE CONTINUE HANDLER FOR NOT FOUND SET flag = 1;

--  打开游标 
OPEN idList;

--  取值设置到临时变量中 
FETCH idList INTO tradeacco;

--  遍历未结束就一直执行
WHILE flag != 1 DO
	SELECT
		COUNT(1) INTO v_rowcount
	FROM
		tc_tcapitalacco
	WHERE
		VC_TRADE_ACCO = tradeacco
	AND c_capital_mode = 'BL';


IF v_rowcount = 0 THEN

	INSERT INTO TC_TCAPITALACCO (
		VC_TENANT_ID,
		VC_CUST_NO,
		VC_TRADE_ACCO,
		VC_CAP_ACCO,
		VC_BANK_CARD_NO,
		C_CAPITAL_MODE,
		C_SUB_CAPITAL_MODE,
		VC_CD_CARD,
		C_INTERFACE_TYPE,
		C_CAP_ACCO_STATE,
		VC_LAST_DATE
	) SELECT
		a.VC_TENANT_ID,
		a.VC_CUST_NO,
		a.VC_TRADE_ACCO,
		NEXT_VAL('QCAPACCO'),
		a.VC_BANK_CARD_NO,
		'BL',
		'',
		k.VC_CD_CARD,
		'1',
		'0',
		'20210623'
	FROM
		tc_taccoinfo a,
		tc_taccobank b,
		tc_tcapitalacco c,
		tc_tchinaprnsresult k
	WHERE
		b.VC_BANK_ACCO = k.VC_BANK_ACCO
	AND a.VC_BANK_CARD_NO = c.VC_BANK_CARD_NO
	AND c.VC_BANK_CARD_NO = b.VC_BANK_CARD_NO
	AND c.VC_TRADE_ACCO = a.VC_TRADE_ACCO
	AND a.VC_TRADE_ACCO = tradeacco LIMIT 1;


END IF;

FETCH idList INTO tradeacco;


END
WHILE;

CLOSE idList;


END;


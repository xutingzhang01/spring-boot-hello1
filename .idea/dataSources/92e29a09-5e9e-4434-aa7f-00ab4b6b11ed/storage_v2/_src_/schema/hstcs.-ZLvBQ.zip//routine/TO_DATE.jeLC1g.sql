create
    definer = hs@`%` function TO_DATE(date_str tinytext, date_format tinytext) returns date deterministic
begin
    declare return_date date;
    declare mysql_format tinytext;
    set mysql_format = '%Y%m%d';
    select str_to_date(date_str, mysql_format) into return_date;
    return return_date;
end;


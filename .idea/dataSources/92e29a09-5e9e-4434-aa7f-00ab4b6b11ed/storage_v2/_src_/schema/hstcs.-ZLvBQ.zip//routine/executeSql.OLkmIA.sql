create
    definer = hs@`%` procedure executeSql()
BEGIN
  DECLARE
    i INT;
  
  SET i = 0;
  lp :
  LOOP#表名
    
    SET @tablename = substring_index( substring_index(@tables, ',', i + 1 ), ",",- 1 );

    
    SET @dropInsert = CONCAT( 'DROP TRIGGER IF EXISTS ', @tablename, '_trigger_ins;' );

    SET @dropUpdate = CONCAT( 'DROP TRIGGER IF EXISTS ', @tablename, '_trigger_u;' );

    SET @dropDelete = CONCAT( 'DROP TRIGGER IF EXISTS ', @tablename, '_trigger_d;' );

    SET @sqls = CONCAT(@sqls, @dropInsert, @dropUpdate, @dropDelete);
    
    SET i = i + 1;
    IF
      i > @nums THEN
        LEAVE lp;
      
    END IF;
    
  END LOOP;
  SELECT
    @sqls;

END;


create
    definer = hs@`%` procedure clear_data()
begin
    declare sys_date varchar(8) default '20200831';
    update TC_TSYSPARAMETER set vc_value = sys_date
    where upper(vc_item) = 'SYSDATE';
end;


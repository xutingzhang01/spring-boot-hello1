create
    definer = hs@`%` function CURRENT_VAL(seq_name varchar(50)) returns decimal(32)
BEGIN
    DECLARE value Integer;
		SET value = 0;
   SELECT current_value INTO value
    FROM TC_TSEQUENCE
    WHERE name = seq_name;
    RETURN value;
END;


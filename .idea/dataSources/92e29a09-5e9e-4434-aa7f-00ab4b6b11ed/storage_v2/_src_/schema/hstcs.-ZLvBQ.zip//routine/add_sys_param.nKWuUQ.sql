create
    definer = hs@`%` procedure add_sys_param()
begin
    declare
        v_rowcount integer;
    select count(1) into v_rowcount from tc_tsysparameter where upper(vc_item) = upper('SETLIMITWHENIMPTA');
    if v_rowcount = 0 then
        insert into tc_tsysparameter (VC_TENANT_ID, VC_KIND, VC_ITEM, VC_VALUE, C_MODIFY, VC_DESCRIBE, C_CRYPT_FLAG, C_TYPE, VC_VALUE_BOUND, VC_SHOW_TYPE, VC_SHOW_TYPE2, L_ORDER, VC_SYS_NAME, VC_EXPECTED_VALUE, VC_OPERATOR_NO, VC_AUDIT_NO, C_AUTO_MODIFY, VC_REMARK, VC_SHOW_TYPE3, VC_DEFAULT_VALUE, VC_COND_ITEM, VC_COND_OPERATOR, VC_COND_VALUE)
        values ('10000', '交易类', 'SETLIMITWHENIMPTA', 'ALL', null, '支持导入行情时更新交易限制设置的TA', null, '0', null, null, null, null, '交易中心', null, null, null, '0', null, null, 'ALL', null, null, null);
    else
        update tc_tsysparameter set vc_value = 'ALL' where upper(vc_item) = upper('SETLIMITWHENIMPTA');
    end if;
end;


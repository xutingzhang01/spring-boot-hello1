create
    definer = hs@`%` function TO_CHAR(input_date date, date_format tinytext) returns tinytext deterministic
begin
    declare return_str tinytext;
    declare mysql_format tinytext;
    set mysql_format = '%Y%m%d';
    select date_format(input_date, mysql_format) into return_str;
    return return_str;
end;


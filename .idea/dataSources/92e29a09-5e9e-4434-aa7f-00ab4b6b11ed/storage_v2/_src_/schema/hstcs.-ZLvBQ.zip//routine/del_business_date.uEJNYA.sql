create
    definer = hs@`%` procedure del_business_date()
begin
    declare sql_statement varchar(1000);
    declare done_flag     int default false;
    declare dbexecenv_int int;
    declare sql_env       varchar(50) default 'TEST';
    declare db_env        varchar(50);
    declare error_no      varchar(20);
    declare error_msg     varchar(255);
    declare cur cursor for 
select concat(' truncate table ', table_name) from information_schema.tables WHERE 
       TABLE_SCHEMA = (select database()) 
   AND TABLE_TYPE = 'BASE TABLE' 
   AND TABLE_NAME not in
(
'SHOW_CONFIG',
'SHOW_CONFIG_FIELD',
'SHOW_CONFIG_FIELD_USER',
'SHOW_CONFIG_GROUP',
'SHOW_CONFIG_GROUP_TENANT',
'TC_TBUSINFLAG',
'TC_TBUSINFLAGCFG',
'TC_TBUSINPERMISSION',
'TC_TCAPITALMODECFG',
'TC_TCHILDCENTER',
'TC_TDICTIONARY',
'TC_TDISCOUNT',
'TC_TNETSTATION',
'TC_TOPENDAY',
'TC_TPRODUCTCFG',
'TC_TQUESTIONNAIRE',
'TC_TQUESTIONOPTION',
'TC_TQUESTIONRISK',
'TC_TQUESTIONVERSION',
'TC_TSYSPARAMETER',
'TC_TTAINFO',
'TC_TTRUSTPERMISSION',
'TC_TFUNDCOMEFROM',
'TC_TPRODUCTINFO',
'TC_TPRODUCTINFODETAIL',
'TC_TPRODUCTSHARETYPE',
'TC_TQUESTIONMANAGER',
'TC_TQUESTIONMINRISK',
'TC_TRECOMMANDER',
'TC_TRISKLIMIT',
'TC_TBLACKLIST',
'TC_TEMPLOYEE',
'TC_TPRODUCTMARKET',
'TC_TPRODUCTSTATESCHEDULE',
'TC_TBUSINSETUPMUX',
'TC_TCAPITALBUSIN',
'TC_TCAPITALDATE',
'TC_TCITY',
'TC_TGROUP',
'TC_TKJZFLIMIT',
'TC_TZHPRODUCTLIMIT',
'TC_TBIZ_RULE',
'LC_TDEALPROCESS',
'TC_TSEAT',
'TC_TBROKER',
'TC_TSALE',
'TC_TBANKACCO',
'TC_TBUSINVOUCHER',
'TC_TVOUCHER',
'TC_TFILECLASS',
'TC_TMENU',
'TC_TREPORT',
'TC_TREPORTCLASS',
'TC_TREPORTCLASSRELATION',
'TC_TBANKACCORULE',
'TC_TBROKERRATIO',
'TC_TTIMELIMIT',
'TC_TTRUSTDISCOUNT',
'TC_TWARNINGCONTENT',
'TC_TSMSSENDCFG',
'TC_TUOTMESSAGEVERSION',
'TC_TLIMIT',
'TC_TSUMLIMIT',
'TC_TAMLLISTINFO',
'TC_TAPPROPRIATENESSLIMIT',
'TC_TAPPROPRIATENESSFIELDSCFG',
'TC_TEXPSETTING',
'TC_TFAREZONE',
'TC_TSPECINFO',
'TC_TFREEQUERY',
'TC_TGIRDVIEWS',
'TC_TLATERFUNDINFO',
'TC_TSTAMPINFO',
'TA_TFTPCFG',
'TA_TBUSINFLAG',
'TA_TPLATFILEUPLOAD',
'TA_TPLATFILEDOWNLOAD',
'TA_TFUNDCOMEFROM',
'TA_TINTERFACENEED',
'TA_TINTERFACEDEFAULT',
'TA_TDICTIONARY',
'TA_TUPLOADBATCHCFG',
'TA_TPROCESSSTATUS',
'TA_TSYSPARAMETER',
'SEQUENCE',
'TC_TEXPSCHEMA',
'TC_TEXPSCHEMASCALE',
'TC_TOPENDAY_TMP',
'TC_TEMPLOYEELIMITPRODUCT'
)
and TABLE_NAME not like '%$%'
and TABLE_NAME not like 'QRTZ%'
and TABLE_NAME not like 'BATCH%';
declare continue handler for not found set done_flag = true;

    -- 检查是否存在数据库环境参数配置
    select count(1) into dbexecenv_int from tc_tsysparameter
        where upper(vc_item) = 'DBEXECENV';

    -- 如果参数未配置则抛出异常[20009]
    if dbexecenv_int = 0 then
        set error_no = '20009';
        set error_msg = '数据库环境参数[DBEXECENV]未配置，请检查！';
        SIGNAL SQLSTATE 'ERROR' SET mysql_errno = error_no, message_text = error_msg;
    end if;

    -- 检查脚本执行环境与数据库环境是否相符
    select vc_value into db_env from tc_tsysparameter
        where upper(vc_item) = 'DBEXECENV';

    -- 如果环境不相符则抛出异常[20010]
    if db_env is null or sql_env <> db_env then
        set error_no = '20010';
        set error_msg = concat('数据库环境[',ifnull(DB_ENV,''),']与脚本环境[',SQL_ENV,']不一致，请检查！');
        SIGNAL SQLSTATE 'ERROR' SET mysql_errno = error_no, message_text = error_msg;
    end if;
        
-- 清除业务表数据
open cur;
    read_loop : loop
        fetch cur into sql_statement;
        if done_flag then
            leave read_loop;
        end if;
        set @execute_sql = sql_statement;
        prepare sql_stmt from @execute_sql;
        execute sql_stmt;
        deallocate prepare sql_stmt;
    end loop;
close cur;
end;


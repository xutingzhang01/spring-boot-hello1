create
    definer = hs@`%` procedure trim_field_include()
begin
	declare table_schema varchar(100);
    DECLARE each_table_name VARCHAR(50);
    DECLARE each_column_name TEXT(50000);
    DECLARE done int default 0;
    declare isdone int default 0;
    declare start_time integer unsigned default 0;
    declare end_time integer unsigned default 1;
    DECLARE cur CURSOR FOR
        select a.table_schema as table_schema ,b.TABLE_NAME                   as each_table_name,
            case when  b.is_nullable='yes' then 
               GROUP_CONCAT(CONCAT(COLUMN_NAME, " = (case when length(trim(",
                                   COLUMN_NAME, ")) = 0 then null else trim(", COLUMN_NAME,
                                   ") end)"))
                 else
                      GROUP_CONCAT(CONCAT(COLUMN_NAME,"=trim(", COLUMN_NAME,
                                   ")"))
                             end
                                  as each_column_name
        from table_names_include a,
             information_schema.columns b
        where a.TABLE_NAME = b.TABLE_NAME
          and a.table_schema = b.table_schema
          and b.TABLE_NAME not like 'batch_%'
          and b.TABLE_NAME not like 'qrtz_%'
		  and b.TABLE_NAME <> 'tc_tschedule'
		  and b.TABLE_NAME <> 'tc_tschedulelog'
			and b.TABLE_NAME <> 'tc_thchinapaycompresult'
			and b.TABLE_NAME <> 'tc_tchinapaycompresult'
          and b.TABLE_NAME <> 'sequence'
          and b.DATA_TYPE in ('varchar', 'char')
        group by b.TABLE_NAME;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;
    OPEN cur;
    FETCH cur INTO table_schema,each_table_name, each_column_name;
    WHILE (done <> 1)
        do
			select count(*) into isdone from trim_log where table_name=concat(table_schema,".", each_table_name) ;
           
            if(isdone>0) then 
            	set isdone=0;
            else
            set @log_sql = CONCAT("INSERT INTO trim_log (table_name,etime,log) VALUES ('",table_schema,".",each_table_name,"','",0,"','",
                                  CONCAT("update ",table_schema,".", each_table_name, " set ", each_column_name, ";"), "');");
            prepare log_stmt from @log_sql;
            execute log_stmt;
            commit;
            deallocate prepare log_stmt;
           
			select unix_timestamp() into start_time;
            set @update_sql =
                    CONCAT("update ",table_schema,".", each_table_name, " set ", each_column_name, ";");
            prepare stmt from @update_sql;
            execute stmt;
            commit;
            deallocate prepare stmt;
			select unix_timestamp() into end_time;
		
		    set @updatetime_sql=concat("update trim_log set etime=",(end_time-start_time)," where table_name='",table_schema,".",each_table_name,"';"); 
			prepare time_stmt from @updatetime_sql;
            execute time_stmt;
            commit;
            deallocate prepare time_stmt;
			end if;
            FETCH cur INTO table_schema,each_table_name, each_column_name;
        END WHILE;
END;


create
    definer = hs@`%` procedure add_colum()
BEGIN
IF  NOT EXISTS (select column_name from information_schema.columns where table_name = 'PAYCHANNEL_TRADING_INFO' and column_name = 'VC_SEND_NUM' and TABLE_SCHEMA = database() ) THEN
alter table PAYCHANNEL_TRADING_INFO add column VC_SEND_NUM  varchar(3) DEFAULT NULL  COMMENT '及时扣款轮询次数';
END IF;
END;


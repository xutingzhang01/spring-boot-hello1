create
    definer = hs@`%` function conctnull(str tinytext, str2 tinytext) returns tinytext deterministic
begin
    declare a TINYTEXT;
    declare b TINYTEXT;
    declare c TINYTEXT;

    case when str is null then
        set a = '';
        else
            set a=str;
        end case;
    case when str2 is  null then
        set  b = '';
        else
            set b = str2;
        end case;
    select concat(a , b) into c;
    return c;
end;


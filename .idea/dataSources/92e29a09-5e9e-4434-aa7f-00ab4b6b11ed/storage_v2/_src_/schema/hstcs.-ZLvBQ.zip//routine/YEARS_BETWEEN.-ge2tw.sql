create
    definer = hs@`%` function YEARS_BETWEEN(DAY1 tinytext, DAY2 tinytext) returns tinytext
BEGIN
	DECLARE val DATE;
	DECLARE val2 DATE;
	set val = TO_DATE(NVL(DAY1, 'a'), 'yyyy-mm-dd hh24:mi:ss');
	set val2 = TO_DATE(NVL(DAY2, 'a'), 'yyyy-mm-dd hh24:mi:ss');
    return CONCAT(TRUNCATE(MONTHS_BETWEEN(val, val2)/12, 0), '');
END;


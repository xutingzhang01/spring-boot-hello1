create
    definer = hs@`%` function is_date(parameter tinytext) returns tinyint
BEGIN
	IF (SELECT DATE_FORMAT( parameter, '%Y%m%d' )) IS NULL THEN
		RETURN 0;
	ELSE
		RETURN 1;
	END IF;
END;


create
    definer = hs@`%` function CheckIDCardVALID(VC_IDCard tinytext) returns tinyint
begin
 DECLARE r             TINYTEXT;
 DECLARE i             TINYINT;
 DECLARE VC_TmpIDCard  TINYTEXT;
 DECLARE en_returncode TINYINT;

 set i             = 0;
 set en_returncode = 0;
 set VC_TmpIDCard  = TRIM(VC_IDCard);
  if (char_length(VC_TmpIDCard) = 15) and
     (char_length(REPLACE(VC_TmpIDCard,
                        '0123456789' || VC_TmpIDCard,
                        '0123456789')) = 15) then
    if IS_DATE('19'||substring(VC_TmpIDCard, 7, 6)) = 1 then
     set en_returncode = 1;
    end if;
  else
    if (char_length(VC_TmpIDCard) = 18) and
       (char_length(REPLACE(substring(VC_TmpIDCard, 1, 17),
                          '0123456789' || substring(VC_TmpIDCard, 1, 17),
                          '0123456789')) = 17) then

      if IS_DATE(substring(VC_TmpIDCard, 7, 8)) = 1 then
       set i = cast(substring(VC_TmpIDCard, 1, 1) as SIGNED) * 7 +
             cast(substring(VC_TmpIDCard, 2, 1) as SIGNED) * 9 +
             cast(substring(VC_TmpIDCard, 3, 1) as SIGNED) * 10 +
             cast(substring(VC_TmpIDCard, 4, 1) as SIGNED) * 5 +
             cast(substring(VC_TmpIDCard, 5, 1) as SIGNED) * 8 +
             cast(substring(VC_TmpIDCard, 6, 1) as SIGNED) * 4 +
             cast(substring(VC_TmpIDCard, 7, 1) as SIGNED) * 2 +
             cast(substring(VC_TmpIDCard, 8, 1) as SIGNED) * 1 +
             cast(substring(VC_TmpIDCard, 9, 1) as SIGNED) * 6 +
             cast(substring(VC_TmpIDCard, 10, 1) as SIGNED) * 3 +
             cast(substring(VC_TmpIDCard, 11, 1) as SIGNED) * 7 +
             cast(substring(VC_TmpIDCard, 12, 1) as SIGNED) * 9 +
             cast(substring(VC_TmpIDCard, 13, 1) as SIGNED) * 10 +
             cast(substring(VC_TmpIDCard, 14, 1) as SIGNED) * 5 +
             cast(substring(VC_TmpIDCard, 15, 1) as SIGNED) * 8 +
             cast(substring(VC_TmpIDCard, 16, 1) as SIGNED) * 4 +
             cast(substring(VC_TmpIDCard, 17, 1) as SIGNED) * 2;

        set i = mod(i, 11);
        set r = cast((case i
             when 0 then 1
             when 1 then 0
             when 2 then 11
             when 3 then 9
             when 4 then 8
             when 5 then 7
             when 6 then 6
             when 7 then 5
             when 8 then 4
             when 9 then 3
             when 10 then 2
             else
                 ''
             end) as char);

        set r = TO_CHAR(r);
        if (r = '11') then
          set r = 'X';
        end if;

        if r = substring(VC_TmpIDCard, 18, 1) then
          set en_returncode = 1;
        end if;

      end if;
    end if;
  end if;
  return en_returncode;
end;


create
    definer = hs@`%` function MONTHS_BETWEEN(DAY1 tinytext, DAY2 tinytext) returns tinytext
BEGIN
	return abs(TIMESTAMPDIFF(MONTH,DAY1, DAY2));
END;


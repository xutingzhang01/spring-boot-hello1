create
    definer = hs@`%` function DAYS_BETWEEN(DAY1 tinytext, DAY2 tinytext) returns tinytext
BEGIN
	DECLARE a1 TINYINT;
	DECLARE a2 TINYINT;
	set a1 = is_date(DAY1);
	if a1 = 0 then
		return '-0';
	end if;
	set a2 = is_date(DAY2);
	if a2 = 0 then
		return '-0';
	end if;
	return CONCAT(abs(datediff(DAY1, DAY2)), '');
END;


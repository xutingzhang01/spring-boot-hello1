create definer = hs@`%` view tdictionary as
select `hstcs`.`tc_tdictionary`.`L_KEY_NO`       AS `L_KEYNO`,
       `hstcs`.`tc_tdictionary`.`C_KEY_VALUE`    AS `C_KEYVALUE`,
       `hstcs`.`tc_tdictionary`.`C_CAPTION`      AS `C_CAPTION`,
       `hstcs`.`tc_tdictionary`.`C_MODIFY`       AS `C_MODIFY`,
       `hstcs`.`tc_tdictionary`.`VC_MEMO`        AS `C_MEMO`,
       `hstcs`.`tc_tdictionary`.`VC_TRANSLATION` AS `VC_TRANSLATION`,
       `hstcs`.`tc_tdictionary`.`L_ORDER`        AS `L_ORDER`
from `hstcs`.`tc_tdictionary`;


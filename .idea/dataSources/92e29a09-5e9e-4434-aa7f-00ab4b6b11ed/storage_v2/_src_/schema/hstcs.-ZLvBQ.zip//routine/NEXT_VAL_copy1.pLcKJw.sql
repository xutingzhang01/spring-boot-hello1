create
    definer = hs@`%` function NEXT_VAL_copy1(seq_name varchar(50)) returns decimal(32) deterministic
BEGIN
    UPDATE sequence
    SET current_value = current_value + increments
    WHERE name = seq_name;
    RETURN CURRENT_VAL(seq_name);
END;


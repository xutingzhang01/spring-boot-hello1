create
    definer = hs@`%` function ADD_MONTHS(input_date date, step int) returns date deterministic
begin
    declare return_date date;
    select ADDDATE(input_date,INTERVAL step MONTH) into return_date;
    return return_date;
end;


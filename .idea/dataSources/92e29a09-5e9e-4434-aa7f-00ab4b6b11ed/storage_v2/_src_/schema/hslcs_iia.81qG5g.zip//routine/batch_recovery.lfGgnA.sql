create
    definer = hs@`%` procedure batch_recovery(IN sourceTname varchar(64), IN limitNum int, IN targetDB varchar(64),
                                              IN bakName varchar(64))
BEGIN
      declare startQuotient int default 0;
			declare startLimit int default 0;
			declare limitNum int default limitNum;
			set @targetTname=CONCAT(sourceTname,'_',DATE_FORMAT(SYSDATE(),'%Y%m%d'),bakName);
			
			set @maxId = CONCAT("select COUNT(1) into @totalNum from ",targetDB,".",@targetTname);
      PREPARE stmt1 FROM @maxId;
      EXECUTE stmt1;
      DEALLOCATE PREPARE stmt1;

			SET @dropTable = CONCAT('drop table if exists ',targetDB,'.',sourceTname);
			PREPARE stmt2 FROM @dropTable;
			EXECUTE stmt2;

      SET @createTable = CONCAT('CREATE TABLE ',targetDB,'.',sourceTname,' LIKE ',targetDB,'.',@targetTname);
			PREPARE stmt3 FROM @createTable;
			EXECUTE stmt3;

			
			set @quotient=  ROUND(@totalNum/limitNum,0);
      
      WHILE startQuotient <= @quotient DO
      set @insertSql = CONCAT("insert into ",targetDB,".",sourceTname," SELECT * from ",targetDB,".",@targetTname," limit ",startLimit," , ",limitNum);
			PREPARE stmt1 FROM @insertSql;
			EXECUTE stmt1;
			set startLimit = startLimit + limitNum;
			set startQuotient = startQuotient + 1;
			SELECT sleep(0.2);
      END WHILE;
END;


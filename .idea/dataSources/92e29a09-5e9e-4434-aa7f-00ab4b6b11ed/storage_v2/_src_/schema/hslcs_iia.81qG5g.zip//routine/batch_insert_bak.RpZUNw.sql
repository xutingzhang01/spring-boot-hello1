create
    definer = hs@`%` procedure batch_insert_bak(IN tname varchar(64), IN limitNum int, IN dbName varchar(64),
                                                IN bakName varchar(64))
BEGIN
      declare startQuotient int default 0;
			declare startLimit int default 0;
			declare limitNum int default limitNum;
			SET @time_name=DATE_FORMAT(SYSDATE(),'%Y%m%d');
			set @maxId = CONCAT("select COUNT(1) into @totalNum from ",dbName,".",tname);
      PREPARE stmt1 FROM @maxId;
      EXECUTE stmt1;
      DEALLOCATE PREPARE stmt1;

			SET @dropTable = CONCAT('drop table if exists ',dbName,'.',tname,'_',@time_name,bakName);
			PREPARE stmt2 FROM @dropTable;
			EXECUTE stmt2;

      SET @createTable = CONCAT('CREATE TABLE ',dbName,'.',tname,'_',@time_name,bakName,' LIKE ',dbName,'.',tname);
			PREPARE stmt3 FROM @createTable;
			EXECUTE stmt3;

			
			set @quotient=  ROUND(@totalNum/limitNum,0);
      
      WHILE startQuotient <= @quotient DO
      set @insertSql = CONCAT("insert into ",dbName,".",tname,'_',@time_name,bakName," SELECT * from ",dbName,".", tname," limit ",startLimit," , ",limitNum);
			PREPARE stmt1 FROM @insertSql;
			EXECUTE stmt1;
			set startLimit = startLimit + limitNum;
			set startQuotient = startQuotient + 1;
			SELECT sleep(0.2);
      END WHILE;
END;


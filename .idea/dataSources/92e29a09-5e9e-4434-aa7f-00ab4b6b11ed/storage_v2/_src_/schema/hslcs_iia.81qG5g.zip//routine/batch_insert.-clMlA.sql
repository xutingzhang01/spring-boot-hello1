create
    definer = hs@`%` procedure batch_insert(IN tname varchar(64), IN limitNum int, IN sourceDB varchar(64),
                                            IN targetDB varchar(64))
BEGIN
      declare startQuotient int default 0;
			declare startLimit int default 0;
			declare limitNum int default limitNum;
			
			set @maxId = CONCAT("select COUNT(1) into @totalNum from ",sourceDB,".",tname);
      PREPARE stmt1 FROM @maxId;
      EXECUTE stmt1;
      DEALLOCATE PREPARE stmt1;

			SET @dropTable = CONCAT('drop table if exists ',targetDB,'.',tname);
			PREPARE stmt2 FROM @dropTable;
			EXECUTE stmt2;

      SET @createTable = CONCAT('CREATE TABLE ',targetDB,'.',tname,' LIKE ',sourceDB,'.',tname);
			PREPARE stmt3 FROM @createTable;
			EXECUTE stmt3;

			
			set @quotient=  ROUND(@totalNum/limitNum,0);
      
      WHILE startQuotient <= @quotient DO
      set @insertSql = CONCAT("insert into ",targetDB,".",tname," SELECT * from ",sourceDB,".",tname," limit ",startLimit," , ",limitNum);
			PREPARE stmt1 FROM @insertSql;
			EXECUTE stmt1;
			set startLimit = startLimit + limitNum;
			set startQuotient = startQuotient + 1;
			SELECT sleep(0.2);
      END WHILE;
END;


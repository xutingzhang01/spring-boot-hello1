create
    definer = hs@`%` function next_val_liq(seq_name varchar(50), step int) returns int deterministic
begin
    DECLARE num Integer;
update lc_tsequence t
set t.current_value = t.current_value + step
where t.name = seq_name ;
select current_value into num  from lc_tsequence where name = seq_name;
return num;
end;


create
    definer = hs@`%` function nvl(source_str tinytext, target_str tinytext) returns tinytext
begin
	if source_str is null or source_str = '' then
		return target_str;
	end if;

	return source_str;
end;


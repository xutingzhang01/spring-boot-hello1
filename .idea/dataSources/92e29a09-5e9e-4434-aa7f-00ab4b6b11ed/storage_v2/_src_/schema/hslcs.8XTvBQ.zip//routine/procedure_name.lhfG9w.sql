create
    definer = hs@`%` procedure procedure_name()
BEGIN 
IF not EXISTS (select * from cc_tsysparameter where VC_TENANT_ID='10000' and VC_SUBSYSTEM_NO='CC' and L_SERIAL_NO='1000531')
THEN
 insert into cc_tsysparameter (VC_TENANT_ID, VC_SUBSYSTEM_NO, L_SERIAL_NO, VC_DESCRIBE, VC_TYPE, VC_VALUE_BOUND, VC_MULTI, VC_VALUE, VC_SHOW_TITLE, VC_SHOW_SUBTITLE, L_ORDER, VC_ALIGN, C_MODIFY, VC_CRYPTFLAG, VC_FULL_DESCRIBE, VC_ISNULL, L_ADD_DATE, VC_USE_TYPE)
	values ('10000', 'CC', 1000531, '系统版本号', '5', null, '0', 'FS5.0-FINPSS-CCS.V202005.00.000', '2.清算处理', '4.系统级参数', 1000531, '1', '2', '0', null, '1', 20090407, '2');
else
	update cc_tsysparameter set VC_VALUE='FS5.0-FINPSS-CCS.V202005.00.000' where VC_TENANT_ID='10000' and VC_SUBSYSTEM_NO='CC' and L_SERIAL_NO='1000531';
END IF;  
END;


create
    definer = hs@`%` procedure add_sys_param()
begin
    declare cnt integer;
    SELECT COUNT(1) INTO cnt FROM LC_TSYSPARAMETER WHERE UPPER(VC_ITEM) = 'SUPPORTMANDATORYPROMPT';
    if cnt = 0 then
        insert into LC_TSYSPARAMETER
        (VC_TENANT_ID, VC_KIND, VC_ITEM, VC_VALUE, C_MODIFY, VC_DESCRIBE, C_CRYPT_FLAG, C_TYPE, VC_VALUE_BOUND,
         VC_SYS_NAME, VC_EXPECTED_VALUE, VC_OPERATOR_NO, VC_AUDIT_NO, C_AUTO_MODIFY, VC_DEFAULT_VALUE,VC_SHOW_TYPE,
         VC_SHOW_TYPE2, VC_SHOW_TYPE3, L_ORDER,VC_COND_ITEM, VC_COND_OPERATOR, VC_COND_VALUE)
        values
        ('10000','SALE','SUPPORTMANDATORYPROMPT',null,null,'是否支持校验强制提示',null,null,'0-否;1-是',
         '清算中心',null,null,null,'0','1',null,null,null,null,null,null,null);
     else
        UPDATE LC_TSYSPARAMETER SET VC_DEFAULT_VALUE ='1' WHERE VC_ITEM = UPPER('SUPPORTMANDATORYPROMPT');
    end if;
end;


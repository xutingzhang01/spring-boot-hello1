create
    definer = hs@`%` procedure my_test_proc()
begin
    declare v_rowcount integer;
select count(1) into v_rowcount from LC_TSYSPARAMETER where vc_tenant_id = '10000' and VC_ITEM = 'ISNOTEXISTCONFIRMTRADEREQUEST';
if v_rowcount = 0 then
    insert into LC_TSYSPARAMETER (VC_TENANT_ID, VC_KIND, VC_ITEM, VC_VALUE, C_MODIFY, VC_DESCRIBE, C_CRYPT_FLAG, C_TYPE, VC_VALUE_BOUND,VC_SYS_NAME, VC_EXPECTED_VALUE, VC_OPERATOR_NO, VC_AUDIT_NO, C_AUTO_MODIFY, VC_DEFAULT_VALUE,VC_SHOW_TYPE, VC_SHOW_TYPE2, VC_SHOW_TYPE3, L_ORDER,VC_COND_ITEM, VC_COND_OPERATOR, VC_COND_VALUE)
    values ('10000','SALE','ISNOTEXISTCONFIRMTRADEREQUEST','','1','存在未确认的交易类申请是否不终止流程','0','0','0或空:终止,1-不终止','清算中心','','','','0','0','3004','4024','5026',null,'','','');
end if;
end;


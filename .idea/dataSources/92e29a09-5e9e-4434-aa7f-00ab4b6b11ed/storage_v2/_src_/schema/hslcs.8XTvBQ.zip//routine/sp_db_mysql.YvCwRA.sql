create
    definer = hs@`%` procedure sp_db_mysql()
begin
            declare v_rowcount int;
            declare database_name varchar(100);
            select database() into database_name;
            select count(1) into v_rowcount from information_schema.columns where table_schema = database_name and table_name = 'iia_tcomb_trade_request' and column_name = 'vc_comb_fix_busin_flag';
            if v_rowcount = 0 then
                alter table iia_tcomb_trade_request add column vc_comb_fix_busin_flag varchar(2) comment '组合业务辅助代码';
            end if;
        end;


create
    definer = hs@`%` function current_val(seq_name varchar(50)) returns int deterministic
begin
     declare return_value integer;

	 set return_value = 0;
     select current_value into return_value from lc_tsequence where name = seq_name;

     return return_value;
end;


create
    definer = hs@`%` procedure increament(IN seq_name varchar(50), OUT num int)
begin
    START TRANSACTION;
    update sequence t
    set t.current_value = t.current_value + 1
    where t.name = seq_name ;
    select current_value into num  from sequence where name = seq_name;
    commit;
end;


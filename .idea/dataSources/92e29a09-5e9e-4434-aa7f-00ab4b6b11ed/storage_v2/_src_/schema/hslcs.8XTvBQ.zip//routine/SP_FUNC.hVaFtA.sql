create
    definer = hs@`%` procedure SP_FUNC()
BEGIN
    DECLARE CNT INTEGER;
    SELECT COUNT(*) INTO CNT FROM LC_TSYSPARAMETER
    WHERE UPPER(VC_ITEM) = UPPER('DAYCONFIRMMODE') AND VC_TENANT_ID = '10000';
    IF CNT = 0 THEN
        INSERT INTO LC_TSYSPARAMETER (VC_TENANT_ID, VC_KIND, VC_ITEM, VC_VALUE, C_MODIFY, VC_DESCRIBE, C_CRYPT_FLAG,
                                      C_TYPE, VC_VALUE_BOUND, VC_SYS_NAME, VC_EXPECTED_VALUE, VC_OPERATOR_NO,
                                      VC_AUDIT_NO, C_AUTO_MODIFY, VC_DEFAULT_VALUE, VC_SHOW_TYPE, VC_SHOW_TYPE2,
                                      VC_SHOW_TYPE3, L_ORDER, VC_COND_ITEM, VC_COND_OPERATOR, VC_COND_VALUE)
        VALUES ('10000', 'SALE', 'DAYCONFIRMMODE', '0', '0', 'T+0产品成立模式', '', '0', '0-单批次;1-多批次', '清算中心',
                '', '', '', '0', '0', '', '', '', NULL, '', '', '');
    ELSE
        UPDATE LC_TSYSPARAMETER SET VC_DESCRIBE = 'T+0产品成立模式',VC_VALUE_BOUND='0-单批次;1-多批次'
        WHERE UPPER(VC_ITEM) = UPPER('DAYCONFIRMMODE') AND VC_TENANT_ID = '10000';
    END IF;
END;


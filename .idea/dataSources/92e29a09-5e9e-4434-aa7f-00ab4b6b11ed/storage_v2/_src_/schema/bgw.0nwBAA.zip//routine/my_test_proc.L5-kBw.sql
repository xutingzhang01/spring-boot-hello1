create
    definer = hs@`%` procedure my_test_proc()
begin
    declare
v_rowcount integer;
select count(1) into v_rowcount  from BG_TDICTIONARY where L_KEYNO = 1013 ;
if v_rowcount != 0 then
    update bg_tdictionary set VC_TRANSLATION = '当前正在[use],您的验证码为:[code]' where L_KEYNO = '1013' and C_KEYVALUE <> '#' ;
end if;
end;


create
    definer = hs@`%` procedure create_table_proc()
begin
    declare v_rowcount integer;
    select count(1)
    into v_rowcount
    from (select * from information_schema.columns where table_schema = (SELECT DATABASE())) t
    where upper(table_name) = upper('BG_TFAVOURFUNDINFO');
    if v_rowcount = 0 then
        CREATE TABLE `BG_TFAVOURFUNDINFO`
        (
            `L_ID`  int NOT NULL comment '自选基金编号' primary key AUTO_INCREMENT,
            `VC_CLIENT_ID`  varchar(18) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL comment '客户编号',
            `VC_DC_CLIENT_ID`  varchar(18) CHARACTER SET utf8 COLLATE utf8_general_ci   NULL DEFAULT NULL comment '数据中心客户编号',
            `VC_FAVOUR_DATE`  varchar(8) CHARACTER SET utf8 COLLATE utf8_general_ci     NULL DEFAULT NULL comment '自选日期',
            `VC_FAVOUR_PRICE`  varchar(16) CHARACTER SET utf8 COLLATE utf8_general_ci   NULL DEFAULT NULL comment '自选时价格',
            `VC_FUND_CODE`  varchar(6) CHARACTER SET utf8 COLLATE utf8_general_ci     NOT NULL comment '基金代码',
            `VC_FUND_ID`  varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci     NULL DEFAULT NULL comment '产品编号',
            `VC_FUND_KIND`  varchar(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL comment '产品品种',
            `VC_FUND_NAME`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL comment '基金名称',
            `VC_FUND_TYPE` varchar(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL comment '基金类型',
            `VC_FUND_SUB_TYPE` varchar(1) CHARACTER SET utf8 COLLATE utf8_general_ci  NULL DEFAULT NULL comment '基金子类型',
            `VC_FUND_GRADE_LEVEL`  varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL comment '产品评级',
            `VC_FUND_RISK_LEVEL`  varchar(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL comment '基金风险等级',
            `VC_PRE_FUND_YEAR_YIELD_RATE`  varchar(9) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL comment '预期年化收益率',
            `VC_REG_ID`  varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL comment '注册编号',
            `VC_PROD_TERM`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL comment '产品期限',
            `VC_ADD_FAVOUR_TIME`  varchar(8) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL comment '添加自选时间',
            `VC_USER_TYPE`  varchar(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '9' comment '用户类型',
            UNIQUE INDEX `IDX_TFAVOURFUNDINFO` (`VC_CLIENT_ID` , `VC_FUND_CODE` , `VC_USER_TYPE`) USING BTREE
        ) comment = '客户自选基金表'
          ENGINE = InnoDB
          CHARACTER SET = utf8
          COLLATE = utf8_general_ci
          ROW_FORMAT = Dynamic;
    end if;
end;


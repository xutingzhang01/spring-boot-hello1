create
    definer = root@`%` function NEXT_VAL_LIQ(seq_name varchar(50), step int) returns decimal(32) deterministic
BEGIN
    DECLARE num numeric(32,0);
    update sequence t
    set t.current_value = t.current_value + step
    where t.name = seq_name ;
    select current_value into num  from sequence where name = seq_name;
    return num;
END;


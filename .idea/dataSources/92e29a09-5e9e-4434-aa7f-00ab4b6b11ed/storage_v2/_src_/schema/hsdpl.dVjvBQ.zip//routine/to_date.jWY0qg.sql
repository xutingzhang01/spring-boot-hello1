create
    definer = root@`%` function to_date(str tinytext, format tinytext) returns date deterministic
begin
    declare c date;
    declare mysqlFormat TINYTEXT;

    case when lower(format) = 'yyyymmdd' then
        set mysqlFormat = '%Y%m%d';
        when lower(format) = 'yyyy-mm-dd' then
            set mysqlFormat = '%Y-%m-%d';
        when lower(format) = 'yyyymmddhh24miss' or lower(format) = 'yyyymmddhh24mi:ss' then
            set mysqlFormat = '%Y%m%d%H%i%s';
        when lower(format) = 'yyyy-mm-dd hh24:mi:ss' then
            set mysqlFormat = '%Y-%m-%d %H:%i:%s';
        else
            set mysqlFormat = '0';
        end case;

    select str_to_date(str , mysqlFormat) into c;
    return c;
end;


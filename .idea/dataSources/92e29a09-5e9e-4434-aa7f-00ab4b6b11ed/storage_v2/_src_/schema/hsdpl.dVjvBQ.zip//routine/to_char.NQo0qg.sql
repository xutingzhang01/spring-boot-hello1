create
    definer = root@`%` function to_char(date tinytext, format tinytext) returns tinytext deterministic
begin
    declare c TINYTEXT;
    declare mysqlFormat TINYTEXT;

    case when lower(format) = 'yyyymmdd' then
        set mysqlFormat = '%Y%m%d';
        select DATE_FORMAT(date , mysqlFormat) into c;
        when lower(format) = 'yyyy-mm-dd' then
            set mysqlFormat = '%Y-%m-%d';
            select DATE_FORMAT(date , mysqlFormat) into c;
		    when lower(format) = 'yyyymm' then
            set mysqlFormat = '%Y%m';
            select DATE_FORMAT(date , mysqlFormat) into c;
		    when lower(format) = 'yyyy' then
            set mysqlFormat = '%Y';
            select DATE_FORMAT(date , mysqlFormat) into c;
        when lower(format) = 'yyyymmddhh24miss' or lower(format) = 'yyyymmddhh24mi:ss' or lower(format) = 'yyyymmddhh24mmss' then
            set mysqlFormat = '%Y%m%d%H%i%s';
            select DATE_FORMAT(date , mysqlFormat) into c;
		    when lower(format) = 'yyyy-mm-dd hh24:mi:ss' then
            set mysqlFormat = '%Y-%m-%d %H:%i:%s';
            select DATE_FORMAT(date , mysqlFormat) into c;
        when lower(format) = 'hh24miss' then
            set mysqlFormat = '%H%i%S';
            select DATE_FORMAT(date , mysqlFormat) into c;
		    when format = '9999999999999990.99999999999999' then
            select convert(date , decimal(28,14)) into c;
		    when format = '9999999999999990.999999' then
            select convert(date , decimal(22,6)) into c;
		    when format = '9999999999999990.99999999' then
            select convert(date , decimal(24,8)) into c;
        when format = '9999999999999990.99' or format = 'fm99999999990.99' then
            select convert(date , decimal(18,2)) into c;
        when format = '9999999999999990.9' then
            select convert(date , decimal(18,1)) into c;
        when format = '9999999999999990' then
            select convert(date , decimal(18,0)) into c;
        when format = 'fm9999999999990.0000000000000000' then
            select convert(date , decimal(50,16)) into c;
        when format = 'fm99999999999990.0000' then
            select convert(date , decimal(60,4)) into c;
         when format = '9999999999999990.9999' then
            select convert(date , decimal(60,4)) into c;
        else
            set mysqlFormat = '0';
            select DATE_FORMAT(date , mysqlFormat) into c;
        end case;
    return c;
end;


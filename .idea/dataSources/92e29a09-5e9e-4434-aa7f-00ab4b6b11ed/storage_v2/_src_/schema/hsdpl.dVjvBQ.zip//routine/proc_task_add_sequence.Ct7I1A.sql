create
    definer = hs@`%` procedure proc_task_add_sequence(IN sequenceName varchar(50), IN currentValue int, IN increments int)
BEGIN
    SELECT COUNT(*) INTO @cnt from api_task_sequence where VC_NAME = upper(sequenceName);
    IF @cnt = 0 THEN
        insert into api_task_sequence (VC_NAME, L_CURRENT_VALUE, L_INCREMENTS)
        values (upper(sequenceName), currentValue, increments);
        commit;
    END IF;
END;


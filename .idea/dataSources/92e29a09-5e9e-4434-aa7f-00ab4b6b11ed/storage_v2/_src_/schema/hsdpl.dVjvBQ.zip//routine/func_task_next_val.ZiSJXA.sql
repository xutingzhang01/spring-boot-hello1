create
    definer = hs@`%` function func_task_next_val(seq_name varchar(50)) returns int
BEGIN
    UPDATE api_task_sequence
    SET L_CURRENT_VALUE = L_CURRENT_VALUE + L_INCREMENTS
    WHERE VC_NAME = upper(seq_name);
    RETURN func_task_current_val(seq_name);
END;


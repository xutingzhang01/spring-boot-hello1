create
    definer = root@`%` function nlnull(str1 tinytext, str2 tinytext) returns tinytext deterministic
begin
    declare c TINYTEXT;
    select case when str1 is null then str2 when str1 = '' then str2 else str1 end into c;
    return c;
end;


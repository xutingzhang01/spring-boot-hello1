create
    definer = hs@`%` procedure del_show_config(IN CODE varchar(50))
BEGIN
    SET @code = CODE;
    SET @flag = TRUE;
    IF @flag THEN
      -- 删除外关联表 show_config_field
      SET @deleteSql = CONCAT(' DELETE a FROM show_config_field AS a JOIN ',
                              ' show_config AS b ON a.show_config_id = b.id ',
                              ' WHERE b.code=? ');
      PREPARE stmtDelete FROM @deleteSql;
      EXECUTE stmtDelete USING @code;
      -- 删除 show_config
      SET @deleteSql = CONCAT(' DELETE a FROM show_config AS a ',
                              ' WHERE a.code=? ');
      PREPARE stmtDelete FROM @deleteSql;
      EXECUTE stmtDelete USING @code;
      -- 释放
      DEALLOCATE PREPARE stmtDelete;
    END IF;
  END;


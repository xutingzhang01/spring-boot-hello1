create definer = hs@`%` view space_user_view as
select `s`.`env_id`      AS `env_id`,
       `u`.`user_id`     AS `user_id`,
       `u`.`user_name`   AS `user_name`,
       `u`.`org_id`      AS `org_id`,
       `u`.`user_status` AS `user_status`,
       `u`.`user_type`   AS `user_type`,
       `o`.`org_name`    AS `org_name`
from ((`hsots`.`tsys_user` `u` left join `hsots`.`tsys_space_user` `s`
       on (`s`.`user_id` = `u`.`user_id`)) join `hsots`.`tsys_organization` `o`
      on (`o`.`status` >= 0 and `u`.`org_id` = `o`.`org_id`))
where (`u`.`approval_status` is null or `u`.`approval_status` <> '1')
  and (`o`.`approval_status` is null or `o`.`approval_status` <> '1');

-- comment on column space_user_view.env_id not supported: 空间id

-- comment on column space_user_view.user_id not supported: 用户代码

-- comment on column space_user_view.org_id not supported: 所属组织机构

-- comment on column space_user_view.user_status not supported: 用于表示此用户状态取数据字典[SYS_BIZ_USER_STATUS]0-正常1-注销2-禁用

-- comment on column space_user_view.user_type not supported: 取数据字典[SYS_BIZ_USER_CATE]0-柜员1-用户

-- comment on column space_user_view.org_name not supported: 组织名称


create
    definer = hs@`%` procedure menu_proc()
begin
declare
  iCount int;
  select count(1) into iCount from tsys_role_right where TRANS_CODE = 'exportstatequery' and SUB_TRANS_CODE = 'exportstatequery' and ROLE_CODE = '6468fc521a1e43dc'
    and BEGIN_DATE = '0' and END_DATE = '0' and RIGHT_FLAG = '1';
  if (iCount = 0) then
    insert into tsys_role_right (TRANS_CODE, SUB_TRANS_CODE, ROLE_CODE, CREATE_BY, CREATE_DATE, BEGIN_DATE, END_DATE, RIGHT_FLAG, RIGHT_ENABLE)
    values ('exportstatequery','exportstatequery', '6468fc521a1e43dc', 'system',CAST(date_format(now(), '%Y%m%d%k%i%s') AS SIGNED INTEGER),'0','0','1',null);
  end if;
end;


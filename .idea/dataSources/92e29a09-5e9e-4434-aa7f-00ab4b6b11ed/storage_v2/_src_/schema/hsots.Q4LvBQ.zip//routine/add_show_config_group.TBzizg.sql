create
    definer = hs@`%` procedure add_show_config_group(IN VC_SC_GROUP_ID varchar(32), IN VC_SC_GROUP_CODE varchar(50),
                                                     IN VC_SC_GROUP_NAME varchar(50),
                                                     IN VC_SC_GROUP_VERSION varchar(50), IN VC_TENANT_ID varchar(32))
BEGIN
		declare t_total int(32) default 0;
		-- 插入
		select count(*) into t_total from ot_tshowconfiggroup t where t.VC_SC_GROUP_CODE=VC_SC_GROUP_CODE;
		
		if t_total<=0 then
			insert into ot_tshowconfiggroup(VC_SC_GROUP_ID, VC_SC_GROUP_CODE, VC_SC_GROUP_NAME, VC_SC_GROUP_VERSION, VC_TENANT_ID)
			values(VC_SC_GROUP_ID, VC_SC_GROUP_CODE, VC_SC_GROUP_NAME, VC_SC_GROUP_VERSION, VC_TENANT_ID);
		end if;
		commit;
END;


create
    definer = hs@`%` procedure my_test_proc()
begin
declare
v_rowcount integer;
select count(1) into v_rowcount  from (select * from information_schema.columns where table_schema = (SELECT DATABASE())) t
where table_name = upper('OT_TDICTIONARY')
  and column_name = upper('VC_KEY_VALUE');
if v_rowcount != 0 then
alter TABLE OT_TDICTIONARY MODIFY COLUMN VC_KEY_VALUE VARCHAR(30) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL;
end if;
end;


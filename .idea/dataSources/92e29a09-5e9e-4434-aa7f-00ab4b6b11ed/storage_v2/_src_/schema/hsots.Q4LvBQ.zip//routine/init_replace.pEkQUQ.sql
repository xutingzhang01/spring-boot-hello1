create
    definer = hs@`%` procedure init_replace()
BEGIN
 DECLARE    done                     int default 0;
 DECLARE    error_no                 varchar(20);                
DECLARE    error_msg                 varchar(255);                  
 DECLARE icount_table                int default 0;
 DECLARE icount_newworkday           int default 0;
 DECLARE realworkdaytype             varchar(1);
 DECLARE realId                      varchar(10);
 DECLARE record_num                  int default 0;                          
 DECLARE record_fail                 int default 0; 
 DECLARE record_QDII                 int default 0; 
 DECLARE record_TA                    int default 0; 
 DECLARE month1                       int;
 DECLARE month2                       int;
 DECLARE month3                       int;
 DECLARE month4                       int;
 DECLARE month5                       int;
 DECLARE month6                       int;
 DECLARE month7                       int;
 DECLARE month8                       int;
 DECLARE month9                       int;
 DECLARE month10                      int;
 DECLARE month11                      int;
 DECLARE month12                      int;  
 DECLARE nowmonth1                    int;
 DECLARE nowmonth2                    int;
 DECLARE nowmonth3                    int;
 DECLARE nowmonth4                    int;
 DECLARE nowmonth5                    int;
 DECLARE nowmonth6                    int;
 DECLARE nowmonth7                    int;
 DECLARE nowmonth8                    int;
 DECLARE nowmonth9                    int;
 DECLARE nowmonth10                   int;
 DECLARE nowmonth11                   int;
 DECLARE nowmonth12                   int;   
  -- 创建游标
    DECLARE cur_all_2022_workday CURSOR FOR
       SELECT T.I_MONTH1,T.I_MONTH2,T.I_MONTH3,T.I_MONTH4,T.I_MONTH5,T.I_MONTH6,T.I_MONTH7,
     T.I_MONTH8,T.I_MONTH9,T.I_MONTH10,T.I_MONTH11,T.I_MONTH12  FROM OT_TWORKDAY T WHERE T.I_YEAR = '2022';
        -- 指定游标循环结束时的返回值
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;
     
     -- 建正确的工作日信息表
     SELECT count(1) INTO icount_table FROM (SELECT * FROM information_schema.TABLES WHERE table_schema = (SELECT DATABASE())) t
    WHERE 1 = 1 AND upper(table_name) = upper('OT_TWORKDAY_REAL') AND table_type = 'BASE TABLE';
 
     IF icount_table = 0 THEN
       CREATE TABLE `OT_TWORKDAY_REAL` (
     `VC_TENANT_ID` varchar(32) NOT NULL ,
     `C_WORKDAY_TYPE` char(1) NOT NULL ,
     `VC_ID` varchar(20) DEFAULT NULL ,
     `I_YEAR` decimal(38,0) NOT NULL,
     `I_MONTH1` decimal(38,0) DEFAULT NULL,
     `I_MONTH2` decimal(38,0) DEFAULT NULL,
     `I_MONTH3` decimal(38,0) DEFAULT NULL,
     `I_MONTH4` decimal(38,0) DEFAULT NULL,
     `I_MONTH5` decimal(38,0) DEFAULT NULL,
     `I_MONTH6` decimal(38,0) DEFAULT NULL,
     `I_MONTH7` decimal(38,0) DEFAULT NULL,
     `I_MONTH8` decimal(38,0) DEFAULT NULL,
     `I_MONTH9` decimal(38,0) DEFAULT NULL,
     `I_MONTH10` decimal(38,0) DEFAULT NULL,
     `I_MONTH11` decimal(38,0) DEFAULT NULL,
     `I_MONTH12` decimal(38,0) DEFAULT NULL,
     `GMT_CREATE` datetime DEFAULT CURRENT_TIMESTAMP ,
     `GMT_MODIFIED` datetime DEFAULT NULL ,
     `l_no` bigint(20) NOT NULL AUTO_INCREMENT,
     PRIMARY KEY (`l_no`)
     ) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE = utf8_bin ;
 END IF ;

    
   -- 检查是否存在数据库环境参数配置
  select count(1) into icount_newworkday from OT_TWORKDAY_REAL where C_WORKDAY_TYPE='0' AND I_YEAR = '2022';
  if icount_newworkday = 0 then
    insert into OT_TWORKDAY_REAL (VC_TENANT_ID, C_WORKDAY_TYPE, VC_ID, I_YEAR, I_MONTH1, I_MONTH2, I_MONTH3, I_MONTH4, I_MONTH5, I_MONTH6, I_MONTH7, I_MONTH8, I_MONTH9, I_MONTH10, I_MONTH11, I_MONTH12, GMT_CREATE, GMT_MODIFIED) values ('10000', '0', null, 2022, 262094456, 166979520, 2046027727, 524188897, 1741659952, 1023013859,524188921, 1944571807, 1048375795,1335836160, 972285903, 1048377843, now(), now());
  end if;
  
    -- 检查是否存在2022年工作日
  select count(1) into record_num FROM OT_TWORKDAY T WHERE T.I_YEAR = '2022';
  
  if record_num = 0 then
    set error_no = '20009';
    set error_msg = '运营终端数据库中不存在[2022]年工作日信息，请检查！';
    signal sqlstate 'ERROR' set mysql_errno = error_no, message_text = error_msg;
  end if;
  
    SELECT t.c_workday_type , T.VC_ID ,T.I_MONTH1 , T.I_MONTH2 ,  T.I_MONTH3 ,  T.I_MONTH4 ,  T.I_MONTH5,  T.I_MONTH6 ,  T.I_MONTH7 ,  T.I_MONTH8 ,  T.I_MONTH9 ,  T.I_MONTH10 ,   T.I_MONTH11 ,  T.I_MONTH12  into realworkdaytype,realId,month1,month2,month3,month4,month5,month6,month7,month8,month9,month10,month11,month12 FROM OT_TWORKDAY_REAL T WHERE T.I_YEAR = '2022';

  
    OPEN cur_all_2022_workday;
    FETCH cur_all_2022_workday INTO nowmonth1,nowmonth2,nowmonth3,nowmonth4,nowmonth5,nowmonth6,nowmonth7,nowmonth8,nowmonth9,nowmonth10,nowmonth11,nowmonth12;
    WHILE (done<>1) do
     if (month1 != nowmonth1 
        OR month2 != nowmonth2 
        OR month3 != nowmonth3 
        OR month4 != nowmonth4 
        OR month5 != nowmonth5 
        OR month6 != nowmonth6 
        OR month7 != nowmonth7 
        OR month8 != nowmonth8 
        OR month9 != nowmonth9 
        OR month10 != nowmonth10 
        OR month11 != nowmonth11 
        OR month12 != nowmonth12) THEN
        set error_no = '20020';
        set error_msg = '运营终端数据库存在[2022]年工作日,但部分信息不正确，请检查！';
        signal sqlstate 'ERROR' set mysql_errno = error_no, message_text = error_msg;              
       END IF;
      FETCH cur_all_2022_workday INTO nowmonth1,nowmonth2,nowmonth3,nowmonth4,nowmonth5,nowmonth6,nowmonth7,nowmonth8,nowmonth9,nowmonth10,nowmonth11,nowmonth12;
    END WHILE;
    CLOSE cur_all_2022_workday;

     SELECT COUNT(1) into record_QDII from ot_tproductinfo t1 where t1.c_product_type = '5' and t1.c_product_status not in ('3','a')
    and not exists (
    select 1 from ot_tworkday t where t.c_workday_type = '2' and t.vc_id = t1.vc_product_code );
    
      -- 检查非终止、发行失败状态的QDII基金是否未设置工作日
  if record_QDII > 0 then
     set error_no = '20021';
     set error_msg = '运营终端数据库中存在QDII未配置工作日，请检查！';
     signal sqlstate 'ERROR' set mysql_errno = error_no, message_text = error_msg;     
   
  end if;
  
    -- 检查正常状态的TA是否未设置工作日,由于不仅仅是销售，所有不带TA状态；
  /* SELECT COUNT(1) INTO record_TA FROM OT_TTAINFO T WHERE 1=1 AND   and not exists (
    select 1 from ot_tworkday t where t.c_workday_type = '1' and t.vc_id = t.vc_ta_code);
    
    if record_TA > 0 then
     set error_no = '20022';
     set error_msg = '运营终端数据库中存在TA未配置工作日，请检查！';
     signal sqlstate 'ERROR' set mysql_errno = error_no, message_text = error_msg;   
    end if;*/

END;


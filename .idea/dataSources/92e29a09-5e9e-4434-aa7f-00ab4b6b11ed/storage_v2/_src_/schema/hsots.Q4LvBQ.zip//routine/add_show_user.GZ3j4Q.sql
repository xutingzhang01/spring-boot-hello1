create
    definer = hs@`%` procedure add_show_user(IN VC_SC_FIELD_USER_ID varchar(32), IN VC_USER_ID varchar(32),
                                             IN VC_SC_FIELD_ID varchar(32), IN EN_SC_FIELD_USER_SORT decimal(8),
                                             IN C_SC_FIELD_USER_VISIBLE char, IN C_SC_FIELD_USER_FIXABLE char)
BEGIN
		declare t_total int default 0;
		select count(*) into t_total from ot_tshowconfigfielduser t where t.VC_SC_FIELD_USER_ID = VC_SC_FIELD_USER_ID;
		
		if t_total <= 0 then
		insert into ot_tshowconfigfielduser(VC_SC_FIELD_USER_ID, VC_USER_ID, VC_SC_FIELD_ID, EN_SC_FIELD_USER_SORT, C_SC_FIELD_USER_VISIBLE, C_SC_FIELD_USER_FIXABLE) values(VC_SC_FIELD_USER_ID, VC_USER_ID, VC_SC_FIELD_ID, EN_SC_FIELD_USER_SORT, C_SC_FIELD_USER_VISIBLE, C_SC_FIELD_USER_FIXABLE);
		end if;
		commit;
END;


create
    definer = hs@`%` procedure f_show_config(IN opertate_type varchar(32), IN vc_group_code varchar(200),
                                             IN vc_config_code varchar(200), IN vc_name varchar(200),
                                             IN vc_version varchar(32), IN vc_services_type varchar(32),
                                             IN vc_services varchar(200), IN vc_type varchar(32))
label:BEGIN
  DECLARE t_total int default 0;
  DECLARE t_group_id varchar(32);
	DECLARE t_config_id varchar(32);

	select count(*) into t_total from OT_TSHOWCONFIGGROUP t where t.VC_SC_GROUP_CODE=vc_group_code;

	if t_total<=0  then
	  select concat('show_config_group不存在!', vc_group_code);
	  leave label;
	end if;

	select t.VC_SC_GROUP_ID into t_group_id from OT_TSHOWCONFIGGROUP t where t.VC_SC_GROUP_CODE=vc_group_code;

	select count(*) into t_total from OT_TSHOWCONFIG t where t.VC_SC_GROUP_ID=t_group_id and t.VC_SC_CODE=vc_config_code;

	if t_total<=0 and(opertate_type='2' or opertate_type='3') then
	  select concat('show_config不存在!', vc_config_code);
	  leave label;
	elseif t_total>0 and opertate_type='1' then
		select concat('show_config已存在!',vc_config_code);
		leave label;
	elseif t_total>0 then
		select t.VC_SC_ID into t_config_id from OT_TSHOWCONFIG t where t.VC_SC_GROUP_ID=t_group_id and t.VC_SC_CODE=vc_config_code;
	end if;

	if opertate_type = '1' then
		insert into OT_TSHOWCONFIG values(null,t_group_id,vc_config_code,vc_name,vc_version,vc_services_type,vc_services,vc_type);
  elseif opertate_type='2' then
    delete from OT_TSHOWCONFIG where VC_SC_ID=t_config_id;
		delete from OT_TSHOWCONFIGFIELD where VC_SC_ID = t_config_id;
  elseif opertate_type = '3' then
    update OT_TSHOWCONFIG t set VC_SC_NAME=vc_name,VC_SC_VERSION=vc_version,
		C_SC_SERVICE_TYPE=vc_services_type,VC_SC_SERVICES=vc_services,VC_SC_TYPE=vc_type
		where t.VC_SC_ID=t_config_id;
  end if;
  commit;
end;


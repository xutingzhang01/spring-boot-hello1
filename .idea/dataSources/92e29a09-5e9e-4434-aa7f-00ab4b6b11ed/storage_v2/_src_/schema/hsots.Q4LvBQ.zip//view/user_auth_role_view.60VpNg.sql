create definer = hs@`%` view user_auth_role_view as
select `x1`.`role_code`  AS `role_code`,
       `x1`.`role_name`  AS `role_name`,
       `x1`.`creator`    AS `creator`,
       `x1`.`remark`     AS `remark`,
       `x1`.`parent_id`  AS `parent_id`,
       `x1`.`role_path`  AS `role_path`,
       `x1`.`right_flag` AS `right_flag`,
       `x1`.`user_id`    AS `user_id`
from `hsots`.`tsys_role_user` `x0`
         join `hsots`.`user_roles_view` `x1`
where `x0`.`role_code` = `x1`.`role_code`
  and `x0`.`right_flag` = '2'
  and `x1`.`right_flag` = '2'
union
select `x2`.`role_code` AS `role_code`,
       `x2`.`role_name` AS `role_name`,
       `x2`.`creator`   AS `creator`,
       `x2`.`remark`    AS `remark`,
       `x2`.`parent_id` AS `parent_id`,
       `x2`.`role_path` AS `role_path`,
       '2'              AS `2`,
       `x3`.`user_id`   AS `user_id`
from `hsots`.`tsys_role` `x2`
         join `hsots`.`tsys_user` `x3`
where `x2`.`creator` = `x3`.`user_id`
  and (`x2`.`approval_status` is null or `x2`.`approval_status` <> '1')
  and (`x3`.`approval_status` is null or `x3`.`approval_status` <> '1');


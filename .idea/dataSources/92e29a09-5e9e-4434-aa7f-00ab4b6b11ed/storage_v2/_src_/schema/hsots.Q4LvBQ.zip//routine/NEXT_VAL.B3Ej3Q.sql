create
    definer = hs@`%` function NEXT_VAL(seq_name varchar(50)) returns decimal(32)
BEGIN
UPDATE ot_tsequence
SET current_value = current_value + increment
WHERE name = seq_name;
RETURN CURRENT_VAL(seq_name);
END;


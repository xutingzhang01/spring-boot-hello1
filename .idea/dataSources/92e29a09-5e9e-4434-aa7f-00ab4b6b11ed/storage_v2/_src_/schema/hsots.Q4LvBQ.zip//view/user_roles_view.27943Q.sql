create definer = hs@`%` view user_roles_view as
select `x0`.`role_code`  AS `role_code`,
       `x0`.`role_name`  AS `role_name`,
       `x0`.`creator`    AS `creator`,
       `x0`.`remark`     AS `remark`,
       `x0`.`parent_id`  AS `parent_id`,
       `x0`.`role_path`  AS `role_path`,
       `x1`.`right_flag` AS `right_flag`,
       `x1`.`user_code`  AS `user_id`
from (`hsots`.`tsys_role` `x0` left join `hsots`.`tsys_role_user` `x1` on (`x1`.`role_code` = `x0`.`role_code`))
where (`x0`.`approval_status` is null or `x0`.`approval_status` <> '1')
  and `x0`.`role_status` = '1'
union
select `x2`.`role_code`      AS `role_code`,
       `x2`.`role_name`      AS `role_name`,
       `x2`.`creator`        AS `creator`,
       `x2`.`remark`         AS `remark`,
       `x2`.`parent_id`      AS `parent_id`,
       `x2`.`role_path`      AS `role_path`,
       `x4`.`dict_item_code` AS `dict_item_code`,
       `x3`.`user_id`        AS `user_id`
from (`hsots`.`tsys_role` `x2` left join `hsots`.`user_pos_view` `x3` on (`x2`.`role_code` = `x3`.`role_code`))
         join `hsots`.`tsys_dict_item` `x4`
where `x4`.`dict_entry_code` = 'BIZ_RIGHT_FLAG'
  and (`x2`.`approval_status` is null or `x2`.`approval_status` <> '1')
  and `x2`.`role_status` = '1';


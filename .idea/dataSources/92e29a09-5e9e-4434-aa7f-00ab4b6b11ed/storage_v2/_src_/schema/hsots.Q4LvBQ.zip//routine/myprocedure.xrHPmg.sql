create
    definer = hs@`%` procedure myprocedure()
BEGIN
    DECLARE rightOne int DEFAULT 0;
	DECLARE count_menu int DEFAULT 0;
	DECLARE done int DEFAULT 0;
    DECLARE rs VARCHAR(100) ;
    DECLARE mycursor cursor for
select DISTINCT role_code from tsys_role_right where TRANS_CODE in ('banktranferhandlereview','instructioncheckbyworkflow','instructionrecheck');
DECLARE CONTINUE HANDLER for NOT FOUND set done =1;
select count(1) into count_menu from tsys_role_right where TRANS_CODE in ('banktranferhandlereview','instructioncheckbyworkflow','instructionrecheck');
if count_menu !=0 then
delete from TSYS_MENU where MENU_CODE='instructionrecheck' and KIND_CODE='UOTFRAME';
INSERT INTO TSYS_MENU (MENU_CODE, KIND_CODE, TRANS_CODE, SUB_TRANS_CODE, MENU_NAME, MENU_ARG, MENU_ICON, MENU_URL, WINDOW_TYPE, WINDOW_MODEL, TIP, HOT_KEY, PARENT_CODE, ORDER_NO, OPEN_FLAG, TREE_IDX, REMARK, MENU_PLUGIN_NAME, MENU_PLUGIN_DLL, MENU_TYPE, HELP_URL, TENANT_ID, MODULE_ID, MENU_NO, MENU_LEVEL, MENU_I18N, EXT_FIELD, EXT_FIELD1, EXT_FIELD2, EXT_FIELD3, EXT_FIELD4, EXT_FIELD5, MENU_IS_LEAF, MODULE_TYPE, PARAM, APP_CODE, IS_KEEP_ALIVEA, IS_HIDDEN, LANG_MENU_NAME, HK_MENU_NAME, FONT_NAME, SUB_SYSTEM_NO)
values('instructionrecheck', 'UOTFRAME', 'instructionrecheck', 'instructionrecheck', '指令审批', 'uot/ccs/capitalsettlement/instructionrecheck', NULL, '/finccs/capitalsettlement/instructionrecheck', NULL, NULL, NULL, NULL, 'fundtransfer', 86, NULL, '#bizroot#uot#fundtransfer#instructionrecheck', NULL, NULL, NULL, '2', NULL, '10000', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'finccs', '1', '0', '指令审批', '指令审批', 'iconfont', NULL);
delete from TSYS_TRANS where TRANS_CODE='instructionrecheck';
INSERT INTO TSYS_TRANS (TRANS_CODE, TRANS_NAME, KIND_CODE, MODEL_CODE, REMARK, EXT_FIELD_1, EXT_FIELD_2, EXT_FIELD_3, TENANT_ID, TRANS_ORDER, PARENT_CODE, TREE_IDX)
values('instructionrecheck', '指令审批', 'UOTFRAME', '2', NULL, NULL, NULL, NULL, '10000', 0, 'fundtransfer', '#bizroot#uot#fundtransfer#instructionrecheck');
delete from TSYS_SUBTRANS where TRANS_CODE='instructionrecheck' and SUB_TRANS_CODE='instructionrecheck';
INSERT INTO TSYS_SUBTRANS (TRANS_CODE, SUB_TRANS_CODE, SUB_TRANS_NAME, REL_SERV, REL_URL, CTRL_FLAG, LOGIN_FLAG, REMARK, EXT_FIELD_1, EXT_FIELD_2, EXT_FIELD_3, TENANT_ID, SUB_TRANS_ARG, MODULE_TYPE, SUBTRANS_ORDER)
values('instructionrecheck', 'instructionrecheck', '指令审批', NULL, NULL, '1', '1', NULL, NULL, NULL, NULL, '10000', NULL, NULL, '0');
DELETE FROM TSYS_SUBTRANS_RELURL WHERE URL ='/pss/capitalsettlement/banktranferhandle/commitWorkflowCheck' AND TRANS_CODE ='banktranferhandle' AND SUB_TRANS_CODE ='banktranferhandle';
INSERT INTO TSYS_SUBTRANS_RELURL VALUES ('/pss/capitalsettlement/banktranferhandle/commitWorkflowCheck','banktranferhandle#banktranferhandle','banktranferhandle','banktranferhandle',NULL,'pss_capitalsettlement_banktranferhandle_commitWorkflowCheck');
DELETE FROM TSYS_SUBTRANS_RELURL WHERE URL ='/pss/capitalsettlement/transferinstructions/commitWorkflow' AND TRANS_CODE ='transferinstructions' AND SUB_TRANS_CODE ='transferinstructions';
INSERT INTO TSYS_SUBTRANS_RELURL VALUES ('/pss/capitalsettlement/transferinstructions/commitWorkflow','transferinstructions#transferinstructions','transferinstructions','transferinstructions',NULL,'pss_capitalsettlement_transferinstructions_commitWorkflow');
DELETE FROM TSYS_SUBTRANS_RELURL WHERE URL ='/pss/capitalsettlement/transferinstructioncheckbyworkflow/getInitData' AND TRANS_CODE ='instructionrecheck' AND SUB_TRANS_CODE ='instructionrecheck';
INSERT INTO TSYS_SUBTRANS_RELURL VALUES ('/pss/capitalsettlement/transferinstructioncheckbyworkflow/getInitData','instructionrecheck#instructionrecheck','instructionrecheck','instructionrecheck',NULL,'pss_capitalsettlement_transferinstructions_commitWorkflow');
DELETE FROM TSYS_SUBTRANS_RELURL WHERE URL ='/pss/capitalsettlement/transferinstructioncheckbyworkflow/queryReCheckData' AND TRANS_CODE ='instructionrecheck' AND SUB_TRANS_CODE ='instructionrecheck';
INSERT INTO TSYS_SUBTRANS_RELURL VALUES ('/pss/capitalsettlement/transferinstructioncheckbyworkflow/queryReCheckData','instructionrecheck#instructionrecheck','instructionrecheck','instructionrecheck',NULL,'pss_capitalsettlement_transferinstructioncheckbyworkflow_queryData');
DELETE FROM TSYS_SUBTRANS_RELURL WHERE URL ='/pss/capitalsettlement/banktranferhandle/getBankAcco' AND TRANS_CODE ='instructionrecheck' AND SUB_TRANS_CODE ='instructionrecheck';
INSERT INTO TSYS_SUBTRANS_RELURL VALUES ('/pss/capitalsettlement/banktranferhandle/getBankAcco','instructionrecheck#instructionrecheck','instructionrecheck','instructionrecheck',NULL,'pss_capitalsettlement_banktranferhandle_getBankAcco');
DELETE FROM TSYS_SUBTRANS_RELURL WHERE URL ='/pss/capitalsettlement/transferinstructioncheckbyworkflow/reviewCommand' AND TRANS_CODE ='instructionrecheck' AND SUB_TRANS_CODE ='instructionrecheck';
INSERT INTO TSYS_SUBTRANS_RELURL VALUES ('/pss/capitalsettlement/transferinstructioncheckbyworkflow/reviewCommand','instructionrecheck#instructionrecheck','instructionrecheck','instructionrecheck',NULL,'pss_capitalsettlement_transferinstructioncheckbyworkflow_reviewCommand');
DELETE FROM TSYS_SUBTRANS_RELURL WHERE URL ='/pss/capitalsettlement/transferinstructioncheckbyworkflow/refuseCommand' AND TRANS_CODE ='instructionrecheck' AND SUB_TRANS_CODE ='instructionrecheck';
INSERT INTO TSYS_SUBTRANS_RELURL VALUES ('/pss/capitalsettlement/transferinstructioncheckbyworkflow/refuseCommand','instructionrecheck#instructionrecheck','instructionrecheck','instructionrecheck',NULL,'pss_capitalsettlement_transferinstructioncheckbyworkflow_refuseCommand');
DELETE FROM TSYS_SUBTRANS_RELURL WHERE URL ='/pss/capitalsettlement/transferinstructioncheckbyworkflow/queryDetailData' AND TRANS_CODE ='instructionrecheck' AND SUB_TRANS_CODE ='instructionrecheck';
INSERT INTO TSYS_SUBTRANS_RELURL VALUES ('/pss/capitalsettlement/transferinstructioncheckbyworkflow/queryDetailData','instructionrecheck#instructionrecheck','instructionrecheck','instructionrecheck',NULL,'pss_capitalsettlement_transferinstructioncheckbyworkflow_queryReceiveAndPayData');
DELETE FROM TSYS_SUBTRANS_RELURL WHERE URL ='/pss/capitalsettlement/transferinstructioncheckbyworkflow/queryReceiveAndPayData' AND TRANS_CODE ='instructionrecheck' AND SUB_TRANS_CODE ='instructionrecheck';
INSERT INTO TSYS_SUBTRANS_RELURL VALUES ('/pss/capitalsettlement/transferinstructioncheckbyworkflow/queryReceiveAndPayData','instructionrecheck#instructionrecheck','instructionrecheck','instructionrecheck',NULL,'pss_capitalsettlement_transferinstructioncheckbyworkflow_queryReceiveAndPayData');
end if;
open mycursor;
read_loop:LOOP
		fetch mycursor into rs;
		if done = 1 then
			LEAVE read_loop;
end if ;
select count(1) into rightOne from tsys_role_right where TRANS_CODE = 'instructionrecheck' and role_code = rs and right_flag = '1';
select rightOne;
if rightOne = 0 then
			INSERT INTO TSYS_ROLE_RIGHT(TRANS_CODE, SUB_TRANS_CODE, ROLE_CODE, CREATE_BY, CREATE_DATE, BEGIN_DATE, END_DATE, RIGHT_FLAG, RIGHT_ENABLE)
			values('instructionrecheck', 'instaructionrecheck', rs, 'admin', '20220428', 0, 0, '1', NULL);
end if;
select count(1) into rightOne from tsys_role_right where TRANS_CODE = 'instructionrecheck' and role_code = rs and right_flag = '2';
select rightOne;
if rightOne = 0 then
			INSERT INTO TSYS_ROLE_RIGHT(TRANS_CODE, SUB_TRANS_CODE, ROLE_CODE, CREATE_BY, CREATE_DATE, BEGIN_DATE, END_DATE, RIGHT_FLAG, RIGHT_ENABLE)
			values('instructionrecheck', 'instructionrecheck', rs, 'admin', '20220428', 0, 0, '2', NULL);
end if;
END LOOP;
close mycursor;
END;


create
    definer = hs@`%` procedure trim_field()
BEGIN
    DECLARE each_table_name VARCHAR(50);
    DECLARE each_column_name TEXT(50000);
    DECLARE done int default 0;
    DECLARE cur CURSOR FOR
        select b.TABLE_NAME                   as each_table_name,
               GROUP_CONCAT(CONCAT(COLUMN_NAME, " = (case when length(trim(",
                                   COLUMN_NAME, ")) = 0 then null else trim(", COLUMN_NAME,
                                   ") end)")) as each_column_name
        from information_schema.tables a,
             information_schema.columns b
        where a.TABLE_NAME = b.TABLE_NAME
          and a.TABLE_TYPE = 'BASE TABLE'
          and a.table_schema = (SELECT DATABASE())
          and b.table_schema = (SELECT DATABASE())
          and b.TABLE_NAME not like 'batch_%'
          and b.TABLE_NAME not like 'qrtz_%'
          and b.TABLE_NAME <> 'sequence'
          and b.DATA_TYPE in ('varchar', 'char')
        group by b.TABLE_NAME;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;
    OPEN cur;
    FETCH cur INTO each_table_name, each_column_name;
    WHILE (done <> 1)
        do
            set @log_sql = CONCAT("INSERT INTO trim_log (log) VALUES ('",
                                  CONCAT("update ", each_table_name, " set ", each_column_name, ";"), "');");
            prepare log_stmt from @log_sql;
            execute log_stmt;
            commit;
            deallocate prepare log_stmt;

            set @update_sql =
                    CONCAT("update ", each_table_name, " set ", each_column_name, ";");
            prepare stmt from @update_sql;
            execute stmt;
            commit;
            deallocate prepare stmt;
            FETCH cur INTO each_table_name, each_column_name;
        END WHILE;
END;


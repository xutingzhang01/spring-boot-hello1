create
    definer = hs@`%` function to_char(date tinytext, format tinytext) returns tinytext deterministic
begin 
    declare c TINYTEXT;
		declare mysqlFormat TINYTEXT;

		case when format = 'yyyyMMdd' then
			set mysqlFormat = '%Y%m%d';
			select DATE_FORMAT(date , mysqlFormat) into c;
		when format = 'yyyy-MM-dd' then
			set mysqlFormat = '%Y-%m-%d';
			select DATE_FORMAT(date , mysqlFormat) into c;
		when format = 'HH24MISS' then
			set mysqlFormat = '%H%i%S';		
			select DATE_FORMAT(date , mysqlFormat) into c;
		when format = '99999999999990.9999' then									 
			select convert(date , decimal(18,4)) into c;
		when format = '9999999999999990.999' then
			select convert(date , decimal(18,3)) into c;
		when format = '9999999999999990.99' then									 
			select convert(date , decimal(18,2)) into c;
		when format = '9999999999999990.9' then
			select convert(date , decimal(18,1)) into c;
		when format = '9999999999999990' then
			select convert(date , decimal(18,0)) into c;
		else
			set mysqlFormat = '0';
			select DATE_FORMAT(date , mysqlFormat) into c;
		end case;
    return c;
end;


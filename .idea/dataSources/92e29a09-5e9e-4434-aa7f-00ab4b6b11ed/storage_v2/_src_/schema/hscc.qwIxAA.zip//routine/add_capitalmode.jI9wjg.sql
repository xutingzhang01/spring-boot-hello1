create
    definer = hs@`%` procedure add_capitalmode()
begin
	declare v_rowcount integer;
--  delete from lc_tdictionary where VC_TENANT_ID = '10000' and L_KEY_NO = 1003 and C_KEY_VALUE = 'I';
--  delete from lc_tcapitalmodecfg where C_CAPITAL_MODE = 'I';

  select count(1) into v_rowcount from lc_tdictionary where VC_TENANT_ID = '10000' and L_KEY_NO = 1003 and C_KEY_VALUE = 'CU';
  if v_rowcount = 0 then
		insert into lc_tdictionary (VC_TENANT_ID, L_KEY_NO, C_KEY_VALUE, C_CAPTION, C_MODIFY, VC_MEMO, VC_TRANSLATION, L_ORDER, GMT_CREATE, GMT_MODIFIED)
    values ('10000', 1003, 'CU', '富友直连支付渠道', '0', null, null, null, null, null);
	end if;

	select count(1) into v_rowcount from lc_tcapitalmodecfg where VC_TENANT_ID = '10000' and C_CAPITAL_MODE = 'CU';
	if v_rowcount = 0 then
    insert into lc_tcapitalmodecfg (VC_TENANT_ID, C_CAPITAL_MODE, VC_AUTHORIZE_CODE, VC_AUTHORIZE_CODE_VALID_DATE, C_LIKE_CHINAPAY, C_PAY_TYPE, VC_ALLOW_BANK_NO, C_FIX_CAPITAL_IN_MODE, C_REDEEM_CAPITAL_OUT_MODE, C_CP_IN_BANK, C_CP_IN_BANK_FILE_MODE, C_CP_OUT_BANK, C_FAST_REDEEM, C_NEED_SELECT_TIME, VC_AUDIT_BUSIN_FLAG, C_NEED_CD_CARD, C_NEED_CHECK_TRANSFER, C_NEED_CAP_COMP, C_CAP_COMP_RESULT, C_DOWNLOAD_CAP_COMP_DATA_FLAG, C_CP_IN_BANK_SEND_STATE, C_CP_OUT_BANK_SEND_STATE, C_SUPPORT_MULTI_BANK_CARD, VC_BUSIN_FORBIDDEN, C_SUPPORT_REAL_TIME_RECALL, L_CHANNEL_PRIORITY, C_SUPPORT_PSS_FLAG)
    values ('10000', 'CU', null, '99991231', '1', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, '0', '0', null, null, null, 1, '0');
  end if;
end;


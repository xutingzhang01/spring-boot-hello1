create
    definer = hs@`%` function chartrim(s1 tinytext, s2 tinytext) returns tinytext deterministic
begin
    declare c TINYTEXT;
    select (trim(to_char(s1,s2)))  end into c;
    return c;
end;


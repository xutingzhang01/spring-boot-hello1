create
    definer = hs@`%` procedure add_colum()
BEGIN
IF
NOT EXISTS (select column_name from information_schema.columns where upper(table_name)='CC_TCOMMAND' and upper(column_name)='VC_ORI_NEED_DATE' and TABLE_SCHEMA = database() ) THEN
alter table CC_TCOMMAND
    add column VC_ORI_NEED_DATE VARCHAR(8) COMMENT '原始交收日期';
END IF;
IF
NOT EXISTS (select column_name from information_schema.columns where upper(table_name)='CC_TCOMMAND_HIS' and upper(column_name)='VC_ORI_NEED_DATE' and TABLE_SCHEMA = database() ) THEN
alter table CC_TCOMMAND_HIS
    add column VC_ORI_NEED_DATE VARCHAR(8) COMMENT '原始交收日期';
END IF;
END;


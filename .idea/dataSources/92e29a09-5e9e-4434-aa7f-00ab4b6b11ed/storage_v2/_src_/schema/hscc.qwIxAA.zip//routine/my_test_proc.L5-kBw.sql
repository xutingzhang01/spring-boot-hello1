create
    definer = hs@`%` procedure my_test_proc()
begin
declare
  v_rowcount integer;
declare
  v_rowcount_sys integer;
  select count(1) into v_rowcount  from OT_TBASEINFO where VC_KIND = 'SYSTEM' and VC_ITEM = 'SYSTEMINFOFLAG';
   select count(1) into v_rowcount_sys from OT_TBASEINFO where  VC_KIND = 'SYSTEM' AND VC_ITEM = 'SYSTEMINFOFLAG' AND VC_VALUE like '%FINCCS%';

       if v_rowcount = 0 then
            insert into OT_TBASEINFO (VC_TENANT_ID, VC_KIND, VC_ITEM, VC_VALUE, C_MODIFY, L_ORDER, VC_REMARK)
           values ('10000', 'SYSTEM', 'SYSTEMINFOFLAG', '|FINCCS', '1', null, '支持的子系统标识');
       else if v_rowcount_sys = 0 then
         update OT_TBASEINFO set VC_VALUE = CASE WHEN VC_VALUE ='' or VC_VALUE IS NULL THEN '|FINCCS' ELSE CONCAT(VC_VALUE,'|FINCCS') END  
         	where VC_KIND = 'SYSTEM' and VC_ITEM = 'SYSTEMINFOFLAG';
  end if;
    end if;
end;

